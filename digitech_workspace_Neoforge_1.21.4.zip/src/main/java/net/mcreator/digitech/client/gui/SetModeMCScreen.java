package net.mcreator.digitech.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.PlainTextButton;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.digitech.world.inventory.SetModeMCMenu;
import net.mcreator.digitech.procedures.PreturnGamemodeProcedure;
import net.mcreator.digitech.network.SetModeMCButtonMessage;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class SetModeMCScreen extends AbstractContainerScreen<SetModeMCMenu> {
	private final static HashMap<String, Object> guistate = SetModeMCMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Checkbox creative;
	Checkbox survival;
	Checkbox adventure;
	Button button_phone;
	Button button_wifi;
	Button button_minecraft;
	Button button_save;
	ImageButton imagebutton_no;

	public SetModeMCScreen(SetModeMCMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/gsetdark3.png"), this.leftPos + 0, this.topPos + 0, 0, 0, 176, 166, 176, 166);

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/bar.png"), this.leftPos + 0, this.topPos + -8, 0, 0, 176, 166, 176, 166);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_mode_mc.label_settings"), 0, 4, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_mode_mc.label_current_gamemode"), 64, 26, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_mode_mc.label_gamemode_settings"), 55, 11, -1, false);
		guiGraphics.drawString(this.font,

				PreturnGamemodeProcedure.execute(entity), 84, 38, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_mode_mc.label_change_gamemode_to"), 65, 52, -1, false);
	}

	@Override
	public void init() {
		super.init();
		button_phone = new PlainTextButton(this.leftPos + -1, this.topPos + 35, 51, 20, Component.translatable("gui.digitech.set_mode_mc.button_phone"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetModeMCButtonMessage(0, x, y, z));
				SetModeMCButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}, this.font);
		guistate.put("button:button_phone", button_phone);
		this.addRenderableWidget(button_phone);
		button_wifi = new PlainTextButton(this.leftPos + 1, this.topPos + 59, 46, 20, Component.translatable("gui.digitech.set_mode_mc.button_wifi"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetModeMCButtonMessage(1, x, y, z));
				SetModeMCButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}, this.font);
		guistate.put("button:button_wifi", button_wifi);
		this.addRenderableWidget(button_wifi);
		button_minecraft = new PlainTextButton(this.leftPos + 0, this.topPos + 79, 72, 20, Component.translatable("gui.digitech.set_mode_mc.button_minecraft"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetModeMCButtonMessage(2, x, y, z));
				SetModeMCButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}, this.font);
		guistate.put("button:button_minecraft", button_minecraft);
		this.addRenderableWidget(button_minecraft);
		button_save = Button.builder(Component.translatable("gui.digitech.set_mode_mc.button_save"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetModeMCButtonMessage(3, x, y, z));
				SetModeMCButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}).bounds(this.leftPos + 65, this.topPos + 143, 46, 20).build();
		guistate.put("button:button_save", button_save);
		this.addRenderableWidget(button_save);
		imagebutton_no = new ImageButton(this.leftPos + 159, this.topPos + -10, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/no.png"), ResourceLocation.parse("digitech:textures/screens/nos.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetModeMCButtonMessage(4, x, y, z));
				SetModeMCButtonMessage.handleButtonAction(entity, 4, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_no", imagebutton_no);
		this.addRenderableWidget(imagebutton_no);
		creative = Checkbox.builder(Component.translatable("gui.digitech.set_mode_mc.creative"), this.font).pos(this.leftPos + 65, this.topPos + 96)

				.build();
		guistate.put("checkbox:creative", creative);
		this.addRenderableWidget(creative);
		survival = Checkbox.builder(Component.translatable("gui.digitech.set_mode_mc.survival"), this.font).pos(this.leftPos + 65, this.topPos + 68)

				.build();
		guistate.put("checkbox:survival", survival);
		this.addRenderableWidget(survival);
		adventure = Checkbox.builder(Component.translatable("gui.digitech.set_mode_mc.adventure"), this.font).pos(this.leftPos + 66, this.topPos + 121)

				.build();
		guistate.put("checkbox:adventure", adventure);
		this.addRenderableWidget(adventure);
	}
}
