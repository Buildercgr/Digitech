package net.mcreator.digitech.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.digitech.world.inventory.RedstoneMenuPage1Menu;
import net.mcreator.digitech.network.RedstoneMenuPage1ButtonMessage;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class RedstoneMenuPage1Screen extends AbstractContainerScreen<RedstoneMenuPage1Menu> {
	private final static HashMap<String, Object> guistate = RedstoneMenuPage1Menu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Button button_intro;
	Button button_the_dust;
	Button button_the_repeater;
	Button button_the_comparator;
	Button button_los_generadores_de_energia;
	ImageButton imagebutton_no;
	ImageButton imagebutton_df2;

	public RedstoneMenuPage1Screen(RedstoneMenuPage1Menu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("digitech:textures/screens/redstone_menu_page_1.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(RenderType::guiTextured, texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/bar.png"), this.leftPos + 0, this.topPos + 0, 0, 0, 176, 166, 176, 166);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
	}

	@Override
	public void init() {
		super.init();
		button_intro = Button.builder(Component.translatable("gui.digitech.redstone_menu_page_1.button_intro"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new RedstoneMenuPage1ButtonMessage(0, x, y, z));
				RedstoneMenuPage1ButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 10, this.topPos + 16, 51, 20).build();
		guistate.put("button:button_intro", button_intro);
		this.addRenderableWidget(button_intro);
		button_the_dust = Button.builder(Component.translatable("gui.digitech.redstone_menu_page_1.button_the_dust"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new RedstoneMenuPage1ButtonMessage(1, x, y, z));
				RedstoneMenuPage1ButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 10, this.topPos + 49, 71, 20).build();
		guistate.put("button:button_the_dust", button_the_dust);
		this.addRenderableWidget(button_the_dust);
		button_the_repeater = Button.builder(Component.translatable("gui.digitech.redstone_menu_page_1.button_the_repeater"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new RedstoneMenuPage1ButtonMessage(2, x, y, z));
				RedstoneMenuPage1ButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}).bounds(this.leftPos + 8, this.topPos + 80, 87, 20).build();
		guistate.put("button:button_the_repeater", button_the_repeater);
		this.addRenderableWidget(button_the_repeater);
		button_the_comparator = Button.builder(Component.translatable("gui.digitech.redstone_menu_page_1.button_the_comparator"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new RedstoneMenuPage1ButtonMessage(3, x, y, z));
				RedstoneMenuPage1ButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}).bounds(this.leftPos + 8, this.topPos + 110, 98, 20).build();
		guistate.put("button:button_the_comparator", button_the_comparator);
		this.addRenderableWidget(button_the_comparator);
		button_los_generadores_de_energia = Button.builder(Component.translatable("gui.digitech.redstone_menu_page_1.button_los_generadores_de_energia"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new RedstoneMenuPage1ButtonMessage(4, x, y, z));
				RedstoneMenuPage1ButtonMessage.handleButtonAction(entity, 4, x, y, z);
			}
		}).bounds(this.leftPos + 6, this.topPos + 137, 160, 20).build();
		guistate.put("button:button_los_generadores_de_energia", button_los_generadores_de_energia);
		this.addRenderableWidget(button_los_generadores_de_energia);
		imagebutton_no = new ImageButton(this.leftPos + 149, this.topPos + -1, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/no.png"), ResourceLocation.parse("digitech:textures/screens/nos.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new RedstoneMenuPage1ButtonMessage(5, x, y, z));
				RedstoneMenuPage1ButtonMessage.handleButtonAction(entity, 5, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_no", imagebutton_no);
		this.addRenderableWidget(imagebutton_no);
		imagebutton_df2 = new ImageButton(this.leftPos + 155, this.topPos + 16, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/df2.png"), ResourceLocation.parse("digitech:textures/screens/df2.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new RedstoneMenuPage1ButtonMessage(6, x, y, z));
				RedstoneMenuPage1ButtonMessage.handleButtonAction(entity, 6, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_df2", imagebutton_df2);
		this.addRenderableWidget(imagebutton_df2);
	}
}
