package net.mcreator.digitech.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.PlainTextButton;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.digitech.world.inventory.SettingsGuiMenu;
import net.mcreator.digitech.network.SettingsGuiButtonMessage;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class SettingsGuiScreen extends AbstractContainerScreen<SettingsGuiMenu> {
	private final static HashMap<String, Object> guistate = SettingsGuiMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Button button_time;
	Button button_gamemode;
	Button button_minecraft;
	ImageButton imagebutton_no;

	public SettingsGuiScreen(SettingsGuiMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/gsetdark.png"), this.leftPos + 0, this.topPos + 0, 0, 0, 176, 166, 176, 166);

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/bar.png"), this.leftPos + 0, this.topPos + -9, 0, 0, 176, 166, 176, 166);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.settings_gui.label_settings"), -1, 4, -1, false);
	}

	@Override
	public void init() {
		super.init();
		button_time = new PlainTextButton(this.leftPos + 0, this.topPos + 33, 46, 20, Component.translatable("gui.digitech.settings_gui.button_time"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SettingsGuiButtonMessage(0, x, y, z));
				SettingsGuiButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}, this.font);
		guistate.put("button:button_time", button_time);
		this.addRenderableWidget(button_time);
		button_gamemode = new PlainTextButton(this.leftPos + 0, this.topPos + 57, 67, 20, Component.translatable("gui.digitech.settings_gui.button_gamemode"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SettingsGuiButtonMessage(1, x, y, z));
				SettingsGuiButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}, this.font);
		guistate.put("button:button_gamemode", button_gamemode);
		this.addRenderableWidget(button_gamemode);
		button_minecraft = new PlainTextButton(this.leftPos + -1, this.topPos + 81, 72, 20, Component.translatable("gui.digitech.settings_gui.button_minecraft"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SettingsGuiButtonMessage(2, x, y, z));
				SettingsGuiButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}, this.font);
		guistate.put("button:button_minecraft", button_minecraft);
		this.addRenderableWidget(button_minecraft);
		imagebutton_no = new ImageButton(this.leftPos + 150, this.topPos + -9, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/no.png"), ResourceLocation.parse("digitech:textures/screens/nos.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SettingsGuiButtonMessage(3, x, y, z));
				SettingsGuiButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_no", imagebutton_no);
		this.addRenderableWidget(imagebutton_no);
	}
}
