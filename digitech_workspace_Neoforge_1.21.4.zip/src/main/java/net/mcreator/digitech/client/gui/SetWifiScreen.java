package net.mcreator.digitech.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.PlainTextButton;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

import net.mcreator.digitech.world.inventory.SetWifiMenu;
import net.mcreator.digitech.network.SetWifiButtonMessage;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class SetWifiScreen extends AbstractContainerScreen<SetWifiMenu> {
	private final static HashMap<String, Object> guistate = SetWifiMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	EditBox name;
	EditBox wifi_password;
	Button button_phone;
	Button button_wifi;
	Button button_minecraft;
	Button button_connect1;
	ImageButton imagebutton_no;

	public SetWifiScreen(SetWifiMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		name.render(guiGraphics, mouseX, mouseY, partialTicks);
		wifi_password.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/gsetdark2.png"), this.leftPos + 0, this.topPos + 0, 0, 0, 176, 166, 176, 166);

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/no.png"), this.leftPos + 150, this.topPos + 7, 0, 0, 16, 16, 16, 16);

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/si.png"), this.leftPos + 132, this.topPos + 7, 0, 0, 16, 16, 16, 16);

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/bar.png"), this.leftPos + 0, this.topPos + -8, 0, 0, 176, 166, 176, 166);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		if (name.isFocused())
			return name.keyPressed(key, b, c);
		if (wifi_password.isFocused())
			return wifi_password.keyPressed(key, b, c);
		return super.keyPressed(key, b, c);
	}

	@Override
	public void resize(Minecraft minecraft, int width, int height) {
		String nameValue = name.getValue();
		String wifi_passwordValue = wifi_password.getValue();
		super.resize(minecraft, width, height);
		name.setValue(nameValue);
		wifi_password.setValue(wifi_passwordValue);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_wifi.label_settings"), 0, 4, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_wifi.label_wificonnected"), 55, 12, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_wifi.label_connect_to_wifi"), 55, 33, -1, false);
	}

	@Override
	public void init() {
		super.init();
		name = new EditBox(this.font, this.leftPos + 56, this.topPos + 51, 118, 18, Component.translatable("gui.digitech.set_wifi.name")) {
			@Override
			public void insertText(String text) {
				super.insertText(text);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.digitech.set_wifi.name").getString());
				else
					setSuggestion(null);
			}

			@Override
			public void moveCursorTo(int pos, boolean flag) {
				super.moveCursorTo(pos, flag);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.digitech.set_wifi.name").getString());
				else
					setSuggestion(null);
			}
		};
		name.setMaxLength(32767);
		name.setSuggestion(Component.translatable("gui.digitech.set_wifi.name").getString());
		guistate.put("text:name", name);
		this.addWidget(this.name);
		wifi_password = new EditBox(this.font, this.leftPos + 56, this.topPos + 79, 118, 18, Component.translatable("gui.digitech.set_wifi.wifi_password")) {
			@Override
			public void insertText(String text) {
				super.insertText(text);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.digitech.set_wifi.wifi_password").getString());
				else
					setSuggestion(null);
			}

			@Override
			public void moveCursorTo(int pos, boolean flag) {
				super.moveCursorTo(pos, flag);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.digitech.set_wifi.wifi_password").getString());
				else
					setSuggestion(null);
			}
		};
		wifi_password.setMaxLength(32767);
		wifi_password.setSuggestion(Component.translatable("gui.digitech.set_wifi.wifi_password").getString());
		guistate.put("text:wifi_password", wifi_password);
		this.addWidget(this.wifi_password);
		button_phone = new PlainTextButton(this.leftPos + -1, this.topPos + 35, 51, 20, Component.translatable("gui.digitech.set_wifi.button_phone"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetWifiButtonMessage(0, x, y, z));
				SetWifiButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}, this.font);
		guistate.put("button:button_phone", button_phone);
		this.addRenderableWidget(button_phone);
		button_wifi = new PlainTextButton(this.leftPos + 1, this.topPos + 59, 46, 20, Component.translatable("gui.digitech.set_wifi.button_wifi"), e -> {
		}, this.font);
		guistate.put("button:button_wifi", button_wifi);
		this.addRenderableWidget(button_wifi);
		button_minecraft = new PlainTextButton(this.leftPos + 0, this.topPos + 79, 72, 20, Component.translatable("gui.digitech.set_wifi.button_minecraft"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetWifiButtonMessage(2, x, y, z));
				SetWifiButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}, this.font);
		guistate.put("button:button_minecraft", button_minecraft);
		this.addRenderableWidget(button_minecraft);
		button_connect1 = Button.builder(Component.translatable("gui.digitech.set_wifi.button_connect1"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetWifiButtonMessage(3, x, y, z));
				SetWifiButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}).bounds(this.leftPos + 55, this.topPos + 105, 61, 20).build();
		guistate.put("button:button_connect1", button_connect1);
		this.addRenderableWidget(button_connect1);
		imagebutton_no = new ImageButton(this.leftPos + 159, this.topPos + -10, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/no.png"), ResourceLocation.parse("digitech:textures/screens/nos.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetWifiButtonMessage(4, x, y, z));
				SetWifiButtonMessage.handleButtonAction(entity, 4, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_no", imagebutton_no);
		this.addRenderableWidget(imagebutton_no);
	}
}
