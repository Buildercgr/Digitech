package net.mcreator.digitech.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.digitech.world.inventory.ShopGUIMenu;
import net.mcreator.digitech.procedures.PreturnRemembrmeProcedure;
import net.mcreator.digitech.procedures.PreturnRemembrme2Procedure;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class ShopGUIScreen extends AbstractContainerScreen<ShopGUIMenu> {
	private final static HashMap<String, Object> guistate = ShopGUIMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Button button_search_apps;
	Button button_creating_your_own_app;
	Button button_install;
	Button button_uninstall;
	ImageButton imagebutton_what;
	ImageButton imagebutton_not;

	public ShopGUIScreen(ShopGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 280;
		this.imageHeight = 210;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("digitech:textures/screens/shop_gui.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(RenderType::guiTextured, texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/cuadr.png"), this.leftPos + 14, this.topPos + 96, 0, 0, 64, 64, 64, 64);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.shop_gui.label_welcome_to_the_app_store_here"), 16, 6, -13408513, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.shop_gui.label_some_creations_of_other_modders"), 15, 18, -13408513, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.shop_gui.label_expand_and_improve_digitech_and"), 16, 29, -13408513, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.shop_gui.label_new_apps"), 16, 80, -13408513, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.shop_gui.label_remember_me"), 17, 97, -65536, false);
	}

	@Override
	public void init() {
		super.init();
		button_search_apps = Button.builder(Component.translatable("gui.digitech.shop_gui.button_search_apps"), e -> {
		}).bounds(this.leftPos + 15, this.topPos + 50, 82, 20).build();
		guistate.put("button:button_search_apps", button_search_apps);
		this.addRenderableWidget(button_search_apps);
		button_creating_your_own_app = Button.builder(Component.translatable("gui.digitech.shop_gui.button_creating_your_own_app"), e -> {
		}).bounds(this.leftPos + 101, this.topPos + 50, 134, 20).build();
		guistate.put("button:button_creating_your_own_app", button_creating_your_own_app);
		this.addRenderableWidget(button_creating_your_own_app);
		button_install = Button.builder(Component.translatable("gui.digitech.shop_gui.button_install"), e -> {
		}).bounds(this.leftPos + 17, this.topPos + 138, 61, 20).build(builder -> new Button(builder) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int gx, int gy, float ticks) {
				this.visible = PreturnRemembrme2Procedure.execute(entity);
				super.renderWidget(guiGraphics, gx, gy, ticks);
			}
		});
		guistate.put("button:button_install", button_install);
		this.addRenderableWidget(button_install);
		button_uninstall = Button.builder(Component.translatable("gui.digitech.shop_gui.button_uninstall"), e -> {
		}).bounds(this.leftPos + 10, this.topPos + 139, 72, 20).build(builder -> new Button(builder) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int gx, int gy, float ticks) {
				this.visible = PreturnRemembrmeProcedure.execute(entity);
				super.renderWidget(guiGraphics, gx, gy, ticks);
			}
		});
		guistate.put("button:button_uninstall", button_uninstall);
		this.addRenderableWidget(button_uninstall);
		imagebutton_what = new ImageButton(this.leftPos + 241, this.topPos + 52, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/what.png"), ResourceLocation.parse("digitech:textures/screens/what.png")), e -> {
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_what", imagebutton_what);
		this.addRenderableWidget(imagebutton_what);
		imagebutton_not = new ImageButton(this.leftPos + 29, this.topPos + 106, 32, 32, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/not.png"), ResourceLocation.parse("digitech:textures/screens/not.png")), e -> {
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_not", imagebutton_not);
		this.addRenderableWidget(imagebutton_not);
	}
}
