package net.mcreator.digitech.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

import net.mcreator.digitech.world.inventory.SetWifiGUIMenu;
import net.mcreator.digitech.network.SetWifiGUIButtonMessage;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class SetWifiGUIScreen extends AbstractContainerScreen<SetWifiGUIMenu> {
	private final static HashMap<String, Object> guistate = SetWifiGUIMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	EditBox name;
	EditBox password;
	Checkbox setpassword;
	Button button_set_wifi;

	public SetWifiGUIScreen(SetWifiGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("digitech:textures/screens/set_wifi_gui.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		name.render(guiGraphics, mouseX, mouseY, partialTicks);
		password.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(RenderType::guiTextured, texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		if (name.isFocused())
			return name.keyPressed(key, b, c);
		if (password.isFocused())
			return password.keyPressed(key, b, c);
		return super.keyPressed(key, b, c);
	}

	@Override
	public void resize(Minecraft minecraft, int width, int height) {
		String nameValue = name.getValue();
		String passwordValue = password.getValue();
		super.resize(minecraft, width, height);
		name.setValue(nameValue);
		password.setValue(passwordValue);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_wifi_gui.label_lets_set_your_wifi"), 37, 6, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_wifi_gui.label_if_you_dont_mark_the_set_passwo"), 22, 84, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_wifi_gui.label_password_your_inputed_password"), 9, 94, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.set_wifi_gui.label_will_not_be_available"), 37, 103, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		name = new EditBox(this.font, this.leftPos + 28, this.topPos + 32, 118, 18, Component.translatable("gui.digitech.set_wifi_gui.name")) {
			@Override
			public void insertText(String text) {
				super.insertText(text);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.digitech.set_wifi_gui.name").getString());
				else
					setSuggestion(null);
			}

			@Override
			public void moveCursorTo(int pos, boolean flag) {
				super.moveCursorTo(pos, flag);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.digitech.set_wifi_gui.name").getString());
				else
					setSuggestion(null);
			}
		};
		name.setMaxLength(32767);
		name.setSuggestion(Component.translatable("gui.digitech.set_wifi_gui.name").getString());
		guistate.put("text:name", name);
		this.addWidget(this.name);
		password = new EditBox(this.font, this.leftPos + 28, this.topPos + 115, 118, 18, Component.translatable("gui.digitech.set_wifi_gui.password")) {
			@Override
			public void insertText(String text) {
				super.insertText(text);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.digitech.set_wifi_gui.password").getString());
				else
					setSuggestion(null);
			}

			@Override
			public void moveCursorTo(int pos, boolean flag) {
				super.moveCursorTo(pos, flag);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.digitech.set_wifi_gui.password").getString());
				else
					setSuggestion(null);
			}
		};
		password.setMaxLength(32767);
		password.setSuggestion(Component.translatable("gui.digitech.set_wifi_gui.password").getString());
		guistate.put("text:password", password);
		this.addWidget(this.password);
		button_set_wifi = Button.builder(Component.translatable("gui.digitech.set_wifi_gui.button_set_wifi"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new SetWifiGUIButtonMessage(0, x, y, z));
				SetWifiGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 53, this.topPos + 139, 66, 20).build();
		guistate.put("button:button_set_wifi", button_set_wifi);
		this.addRenderableWidget(button_set_wifi);
		setpassword = Checkbox.builder(Component.translatable("gui.digitech.set_wifi_gui.setpassword"), this.font).pos(this.leftPos + 35, this.topPos + 58)

				.build();
		guistate.put("checkbox:setpassword", setpassword);
		this.addRenderableWidget(setpassword);
	}
}
