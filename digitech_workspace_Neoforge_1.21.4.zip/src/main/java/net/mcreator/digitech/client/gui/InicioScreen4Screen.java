package net.mcreator.digitech.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.digitech.world.inventory.InicioScreen4Menu;
import net.mcreator.digitech.procedures.PreturnfaidProcedure;
import net.mcreator.digitech.network.InicioScreen4ButtonMessage;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class InicioScreen4Screen extends AbstractContainerScreen<InicioScreen4Menu> {
	private final static HashMap<String, Object> guistate = InicioScreen4Menu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	ImageButton imagebutton_mosender;
	ImageButton imagebutton_mossetings;
	ImageButton imagebutton_mossaid;
	ImageButton imagebutton_mineoxexp;
	ImageButton imagebutton_si;
	ImageButton imagebutton_no;
	ImageButton imagebutton_mosender1;

	public InicioScreen4Screen(InicioScreen4Menu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/cgr_logo_negro.png"), this.leftPos + -30, this.topPos + -38, 0, 0, 250, 250, 250, 250);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.inicio_screen_4.label_welcomebienvenid"), -12, -29, -16777216, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.inicio_screen_4.label_do_you_like_this_mod"), 96, -11, -16777216, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.inicio_screen_4.label_shop"), -30, 7, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.inicio_screen_4.label_set"), -30, 43, -12829636, false);
		if (PreturnfaidProcedure.execute(entity))
			guiGraphics.drawString(this.font, Component.translatable("gui.digitech.inicio_screen_4.label_faid"), 24, 7, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.inicio_screen_4.label_wiki"), 51, 7, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.inicio_screen_4.label_bag"), -3, 7, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		imagebutton_mosender = new ImageButton(this.leftPos + -30, this.topPos + -11, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/tarjpant.png"), ResourceLocation.parse("digitech:textures/screens/tarjclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new InicioScreen4ButtonMessage(0, x, y, z));
						InicioScreen4ButtonMessage.handleButtonAction(entity, 0, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mosender", imagebutton_mosender);
		this.addRenderableWidget(imagebutton_mosender);
		imagebutton_mossetings = new ImageButton(this.leftPos + -30, this.topPos + 25, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mossetings.png"), ResourceLocation.parse("digitech:textures/screens/setclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new InicioScreen4ButtonMessage(1, x, y, z));
						InicioScreen4ButtonMessage.handleButtonAction(entity, 1, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mossetings", imagebutton_mossetings);
		this.addRenderableWidget(imagebutton_mossetings);
		imagebutton_mossaid = new ImageButton(this.leftPos + 24, this.topPos + -11, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mossaid.png"), ResourceLocation.parse("digitech:textures/screens/faidclick.png")), e -> {
			if (PreturnfaidProcedure.execute(entity)) {
				PacketDistributor.sendToServer(new InicioScreen4ButtonMessage(2, x, y, z));
				InicioScreen4ButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				if (PreturnfaidProcedure.execute(entity))
					guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mossaid", imagebutton_mossaid);
		this.addRenderableWidget(imagebutton_mossaid);
		imagebutton_mineoxexp = new ImageButton(this.leftPos + 51, this.topPos + -11, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mineoxexp.png"), ResourceLocation.parse("digitech:textures/screens/wikiclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new InicioScreen4ButtonMessage(3, x, y, z));
						InicioScreen4ButtonMessage.handleButtonAction(entity, 3, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mineoxexp", imagebutton_mineoxexp);
		this.addRenderableWidget(imagebutton_mineoxexp);
		imagebutton_si = new ImageButton(this.leftPos + 123, this.topPos + 7, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/sis.png"), ResourceLocation.parse("digitech:textures/screens/si.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new InicioScreen4ButtonMessage(4, x, y, z));
				InicioScreen4ButtonMessage.handleButtonAction(entity, 4, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_si", imagebutton_si);
		this.addRenderableWidget(imagebutton_si);
		imagebutton_no = new ImageButton(this.leftPos + 168, this.topPos + 7, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/nos.png"), ResourceLocation.parse("digitech:textures/screens/no.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new InicioScreen4ButtonMessage(5, x, y, z));
				InicioScreen4ButtonMessage.handleButtonAction(entity, 5, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_no", imagebutton_no);
		this.addRenderableWidget(imagebutton_no);
		imagebutton_mosender1 = new ImageButton(this.leftPos + -3, this.topPos + -11, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mosender.png"), ResourceLocation.parse("digitech:textures/screens/endeclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new InicioScreen4ButtonMessage(6, x, y, z));
						InicioScreen4ButtonMessage.handleButtonAction(entity, 6, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mosender1", imagebutton_mosender1);
		this.addRenderableWidget(imagebutton_mosender1);
	}
}
