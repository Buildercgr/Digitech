package net.mcreator.digitech.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.digitech.world.inventory.MobileWikiMenu;
import net.mcreator.digitech.network.MobileWikiButtonMessage;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class MobileWikiScreen extends AbstractContainerScreen<MobileWikiMenu> {
	private final static HashMap<String, Object> guistate = MobileWikiMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Button button_close;
	ImageButton imagebutton_mosender;
	ImageButton imagebutton_mossetings;
	ImageButton imagebutton_mossaid;
	ImageButton imagebutton_mineoxexp;
	ImageButton imagebutton_mosender1;
	ImageButton imagebutton_no;

	public MobileWikiScreen(MobileWikiMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("digitech:textures/screens/mobile_wiki.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(RenderType::guiTextured, texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);

		guiGraphics.blit(RenderType::guiTextured, ResourceLocation.parse("digitech:textures/screens/bar.png"), this.leftPos + 0, this.topPos + 1, 0, 0, 176, 166, 176, 166);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.mobile_wiki.label_welcomebienvenid"), 15, 25, -65536, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.mobile_wiki.label_this_wiki_is_an_digitech_officia"), 6, 106, -13312, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.mobile_wiki.label_wiki_of_digitech_and_is_affiliat"), 6, 124, -13312, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.mobile_wiki.label_buildercgr"), 6, 142, -256, false);
	}

	@Override
	public void init() {
		super.init();
		button_close = Button.builder(Component.translatable("gui.digitech.mobile_wiki.button_close"), e -> {
			if (true) {
				PacketDistributor.sendToServer(new MobileWikiButtonMessage(0, x, y, z));
				MobileWikiButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 87, this.topPos + 70, 51, 20).build();
		guistate.put("button:button_close", button_close);
		this.addRenderableWidget(button_close);
		imagebutton_mosender = new ImageButton(this.leftPos + 20, this.topPos + 41, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/tarjpant.png"), ResourceLocation.parse("digitech:textures/screens/tarjclick.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new MobileWikiButtonMessage(1, x, y, z));
				MobileWikiButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mosender", imagebutton_mosender);
		this.addRenderableWidget(imagebutton_mosender);
		imagebutton_mossetings = new ImageButton(this.leftPos + 51, this.topPos + 43, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mossetings.png"), ResourceLocation.parse("digitech:textures/screens/setclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new MobileWikiButtonMessage(2, x, y, z));
						MobileWikiButtonMessage.handleButtonAction(entity, 2, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mossetings", imagebutton_mossetings);
		this.addRenderableWidget(imagebutton_mossetings);
		imagebutton_mossaid = new ImageButton(this.leftPos + 87, this.topPos + 43, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mossaid.png"), ResourceLocation.parse("digitech:textures/screens/faidclick.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new MobileWikiButtonMessage(3, x, y, z));
				MobileWikiButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mossaid", imagebutton_mossaid);
		this.addRenderableWidget(imagebutton_mossaid);
		imagebutton_mineoxexp = new ImageButton(this.leftPos + 123, this.topPos + 43, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mineoxexp.png"), ResourceLocation.parse("digitech:textures/screens/wikiclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new MobileWikiButtonMessage(4, x, y, z));
						MobileWikiButtonMessage.handleButtonAction(entity, 4, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mineoxexp", imagebutton_mineoxexp);
		this.addRenderableWidget(imagebutton_mineoxexp);
		imagebutton_mosender1 = new ImageButton(this.leftPos + 27, this.topPos + 66, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mosender.png"), ResourceLocation.parse("digitech:textures/screens/endeclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new MobileWikiButtonMessage(5, x, y, z));
						MobileWikiButtonMessage.handleButtonAction(entity, 5, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mosender1", imagebutton_mosender1);
		this.addRenderableWidget(imagebutton_mosender1);
		imagebutton_no = new ImageButton(this.leftPos + 150, this.topPos + 1, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/no.png"), ResourceLocation.parse("digitech:textures/screens/nos.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new MobileWikiButtonMessage(6, x, y, z));
				MobileWikiButtonMessage.handleButtonAction(entity, 6, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_no", imagebutton_no);
		this.addRenderableWidget(imagebutton_no);
	}
}
