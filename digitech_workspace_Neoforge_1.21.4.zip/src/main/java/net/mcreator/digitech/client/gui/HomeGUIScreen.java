package net.mcreator.digitech.client.gui;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.digitech.world.inventory.HomeGUIMenu;
import net.mcreator.digitech.procedures.PreturnfaidProcedure;
import net.mcreator.digitech.network.HomeGUIButtonMessage;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class HomeGUIScreen extends AbstractContainerScreen<HomeGUIMenu> {
	private final static HashMap<String, Object> guistate = HomeGUIMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	ImageButton imagebutton_mosender;
	ImageButton imagebutton_mossetings;
	ImageButton imagebutton_mossaid;
	ImageButton imagebutton_mineoxexp;
	ImageButton imagebutton_si;
	ImageButton imagebutton_no;
	ImageButton imagebutton_mosender1;

	public HomeGUIScreen(HomeGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("digitech:textures/screens/home_gui.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(RenderType::guiTextured, texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.home_gui.label_welcomebienvenid"), 24, 16, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.home_gui.label_do_you_like_this_mod"), 24, 115, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.home_gui.label_shop"), 24, 61, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.home_gui.label_settings"), 24, 97, -12829636, false);
		if (PreturnfaidProcedure.execute(entity))
			guiGraphics.drawString(this.font, Component.translatable("gui.digitech.home_gui.label_faid"), 96, 61, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.home_gui.label_wiki"), 132, 61, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.digitech.home_gui.label_bag"), 60, 61, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		imagebutton_mosender = new ImageButton(this.leftPos + 24, this.topPos + 43, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/tarjpant.png"), ResourceLocation.parse("digitech:textures/screens/tarjclick.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new HomeGUIButtonMessage(0, x, y, z));
				HomeGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mosender", imagebutton_mosender);
		this.addRenderableWidget(imagebutton_mosender);
		imagebutton_mossetings = new ImageButton(this.leftPos + 24, this.topPos + 79, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mossetings.png"), ResourceLocation.parse("digitech:textures/screens/setclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new HomeGUIButtonMessage(1, x, y, z));
						HomeGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mossetings", imagebutton_mossetings);
		this.addRenderableWidget(imagebutton_mossetings);
		imagebutton_mossaid = new ImageButton(this.leftPos + 96, this.topPos + 43, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mossaid.png"), ResourceLocation.parse("digitech:textures/screens/faidclick.png")), e -> {
			if (PreturnfaidProcedure.execute(entity)) {
				PacketDistributor.sendToServer(new HomeGUIButtonMessage(2, x, y, z));
				HomeGUIButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				if (PreturnfaidProcedure.execute(entity))
					guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mossaid", imagebutton_mossaid);
		this.addRenderableWidget(imagebutton_mossaid);
		imagebutton_mineoxexp = new ImageButton(this.leftPos + 132, this.topPos + 43, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mineoxexp.png"), ResourceLocation.parse("digitech:textures/screens/wikiclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new HomeGUIButtonMessage(3, x, y, z));
						HomeGUIButtonMessage.handleButtonAction(entity, 3, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mineoxexp", imagebutton_mineoxexp);
		this.addRenderableWidget(imagebutton_mineoxexp);
		imagebutton_si = new ImageButton(this.leftPos + 24, this.topPos + 133, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/si.png"), ResourceLocation.parse("digitech:textures/screens/sis.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new HomeGUIButtonMessage(4, x, y, z));
				HomeGUIButtonMessage.handleButtonAction(entity, 4, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_si", imagebutton_si);
		this.addRenderableWidget(imagebutton_si);
		imagebutton_no = new ImageButton(this.leftPos + 51, this.topPos + 133, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/no.png"), ResourceLocation.parse("digitech:textures/screens/nos.png")), e -> {
			if (true) {
				PacketDistributor.sendToServer(new HomeGUIButtonMessage(5, x, y, z));
				HomeGUIButtonMessage.handleButtonAction(entity, 5, x, y, z);
			}
		}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_no", imagebutton_no);
		this.addRenderableWidget(imagebutton_no);
		imagebutton_mosender1 = new ImageButton(this.leftPos + 60, this.topPos + 43, 16, 16, new WidgetSprites(ResourceLocation.parse("digitech:textures/screens/mosender.png"), ResourceLocation.parse("digitech:textures/screens/endeclick.png")),
				e -> {
					if (true) {
						PacketDistributor.sendToServer(new HomeGUIButtonMessage(6, x, y, z));
						HomeGUIButtonMessage.handleButtonAction(entity, 6, x, y, z);
					}
				}) {
			@Override
			public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
				guiGraphics.blit(RenderType::guiTextured, sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
			}
		};
		guistate.put("button:imagebutton_mosender1", imagebutton_mosender1);
		this.addRenderableWidget(imagebutton_mosender1);
	}
}
