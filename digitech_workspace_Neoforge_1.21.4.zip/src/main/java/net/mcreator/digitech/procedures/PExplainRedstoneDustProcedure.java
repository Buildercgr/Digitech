package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PExplainRedstoneDustProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The redstone dust is the principal redstone's conductor. This is the base of all redstone. "), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(
					Component.literal("With this you are going to learn the first property o redstone dust: its called the force. The energy of redstone only can go 15 blocks in one direction withoun a signal spansion like repeaters."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(
					Component.literal("In this exercise you have to put redstone dust with the limit distance of 15 blocks and a lever and a lever in one side. Put a lamp in the other side. Try to turn on the leaver and you can turn on you lamp. "),
					false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Try now with a block of distance more."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("You can\u00B4t turn on the lamp."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("This is another restone\u00B4s propertie: it can\u00B4t go in the water."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("You have finished the first tutorial. Pass to the second one to realn more."), false);
	}
}
