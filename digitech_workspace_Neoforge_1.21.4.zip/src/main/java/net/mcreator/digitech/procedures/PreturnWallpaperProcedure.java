package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.digitech.network.DigitechModVariables;

public class PreturnWallpaperProcedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		if (entity.getData(DigitechModVariables.PLAYER_VARIABLES).Wallpapers == 0) {
			return "Light mode";
		} else if (entity.getData(DigitechModVariables.PLAYER_VARIABLES).Wallpapers == 1) {
			return "Dark mode";
		} else if (entity.getData(DigitechModVariables.PLAYER_VARIABLES).Wallpapers == 2) {
			return "Sword";
		} else if (entity.getData(DigitechModVariables.PLAYER_VARIABLES).Wallpapers == 3) {
			return "Carrot";
		} else if (entity.getData(DigitechModVariables.PLAYER_VARIABLES).Wallpapers == 4) {
			return "Buildercgr";
		}
		return "Unknown";
	}
}
