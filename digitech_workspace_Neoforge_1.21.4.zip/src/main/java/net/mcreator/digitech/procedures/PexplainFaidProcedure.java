package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PexplainFaidProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(
					Component.literal("The first aid option is very essential, with this you can get always a help in combat giving you a totem of undiying an three enderperls. This can be unactived with the gamerule mobileTreats in false. "),
					false);
	}
}
