package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PexplainPressionProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The hoppers are very useful in minigames, but to know redstone you have to learn to use the pressure plates well."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Las tolvas son muy utiles en minijuegos, pero para saber de redstone tienes que aprender a usar bien las placas de presi\u00F3n"), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Let's start with the wooden one: This plaque activates the signal with a person, item or animal. With one of those there is enough energy to produce the 15 block signal."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Empecemos con la de madera: Esta placa activa la se\u00F1al con una persona, item o animal. Con uno de esos hay la energ\u00EDa suficiente como para producir la se\u00F1al de 15 bloques."),
					false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The stone one is the same as the wooden one, but it does not light up with objects on it."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("La de piedra es igual de la de madera, pero no se enciende con objetos encima."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The lightweight one produces the signal with the player or the animals. Its strength depends on the number of entities above it, with 15 maximum sign"), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("La de peso ligero produce la se\u00F1al con el jugador o los animales. Su fuerza depende de la cantidad de entidades encima, con 15 se\u00F1al m\u00E1xima"), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The heavyweight one is the same as the light one, but dividing the signal by two, meaning that with 30 entities on top it has the maximum weight."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("La de peso pesado es igual que la de ligero, pero dividiendo entre dos la se\u00F1al, es decir que con 30 entidades encima tiene el peso m\u00E1ximo."), false);
	}
}
