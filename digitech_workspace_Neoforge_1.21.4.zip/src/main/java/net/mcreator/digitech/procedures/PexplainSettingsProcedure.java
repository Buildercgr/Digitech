package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PexplainSettingsProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal(
					"In settigs button you can edit two settings of the world that without this mod you may need use commands to eddit it. The first is the hour in the game, you can put it in sunrise (0), in day (1000), in afternoon (6000), in sunset (12000), in night (14000) or in midnight (18000). "),
					false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The another one is for eddit the gamemode. It can be survival, creative or adventure. "), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("This can be unactived with the gamerule mobileTreats in false."), false);
	}
}
