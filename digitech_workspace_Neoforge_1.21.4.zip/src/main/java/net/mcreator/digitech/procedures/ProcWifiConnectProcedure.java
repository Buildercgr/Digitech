package net.mcreator.digitech.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.components.EditBox;

import net.mcreator.digitech.network.DigitechModVariables;

import java.util.HashMap;

public class ProcWifiConnectProcedure {
	public static void execute(LevelAccessor world, Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		if ((guistate.containsKey("text:wifi_password") ? ((EditBox) guistate.get("text:wifi_password")).getValue() : "").isEmpty()) {
			if (DigitechModVariables.WorldVariables.get(world).Wifi.contains(guistate.containsKey("text:name") ? ((EditBox) guistate.get("text:name")).getValue() : "")) {
				{
					DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
					_vars.wifi_connected = true;
					_vars.syncPlayerVariables(entity);
				}
			} else {
				if (entity instanceof Player _player)
					_player.closeContainer();
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("There is no wifi with that name"), true);
			}
		} else {
			if (DigitechModVariables.WorldVariables.get(world).Wifi
					.contains((guistate.containsKey("text:name") ? ((EditBox) guistate.get("text:name")).getValue() : "") + ": " + (guistate.containsKey("text:wifi_password") ? ((EditBox) guistate.get("text:wifi_password")).getValue() : ""))) {
				{
					DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
					_vars.wifi_connected = true;
					_vars.syncPlayerVariables(entity);
				}
			} else {
				if (entity instanceof Player _player)
					_player.closeContainer();
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal("Incorrect wifi name or password"), true);
			}
		}
	}
}
