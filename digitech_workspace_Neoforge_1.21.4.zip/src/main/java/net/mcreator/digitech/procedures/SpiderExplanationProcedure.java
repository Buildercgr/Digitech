package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class SpiderExplanationProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The spider has 12 life points and 4 attack points. Its weak point is a good citrus hit."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("La ara\u00F1a tiene 12 puntos de vida y 4 puntos de ataque. Su punto d\u00E9bil es un buen toque c\u00EDtrico."), false);
	}
}
