package net.mcreator.digitech.procedures;

import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.client.gui.components.Checkbox;

import java.util.HashMap;

public class PsavemodeProcedure {
	public static void execute(Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		if (guistate.containsKey("checkbox:survival") && ((Checkbox) guistate.get("checkbox:survival")).selected()) {
			if (entity instanceof ServerPlayer _player)
				_player.setGameMode(GameType.SURVIVAL);
		} else if (guistate.containsKey("checkbox:creative") && ((Checkbox) guistate.get("checkbox:creative")).selected()) {
			if (entity instanceof ServerPlayer _player)
				_player.setGameMode(GameType.CREATIVE);
		} else if (guistate.containsKey("checkbox:adventure") && ((Checkbox) guistate.get("checkbox:adventure")).selected()) {
			if (entity instanceof ServerPlayer _player)
				_player.setGameMode(GameType.ADVENTURE);
		}
	}
}
