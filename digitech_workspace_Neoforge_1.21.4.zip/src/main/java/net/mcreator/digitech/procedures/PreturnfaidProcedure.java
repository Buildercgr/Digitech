package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.digitech.network.DigitechModVariables;

public class PreturnfaidProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return entity.getData(DigitechModVariables.PLAYER_VARIABLES).faidallow;
	}
}
