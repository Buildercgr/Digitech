package net.mcreator.digitech.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.digitech.network.DigitechModVariables;

import java.util.function.Supplier;
import java.util.Map;

public class PloadenderchestProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchest0.copy();
			_setstack.setCount((int) entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchestst0);
			((Slot) _slots.get(0)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchest1.copy();
			_setstack.setCount((int) entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchestst1);
			((Slot) _slots.get(1)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchest2.copy();
			_setstack.setCount((int) entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchestst2);
			((Slot) _slots.get(2)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchest3.copy();
			_setstack.setCount((int) entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchestst3);
			((Slot) _slots.get(3)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchest4.copy();
			_setstack.setCount((int) entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchestst4);
			((Slot) _slots.get(4)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchest5.copy();
			_setstack.setCount((int) entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchestst5);
			((Slot) _slots.get(5)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchest6.copy();
			_setstack.setCount((int) entity.getData(DigitechModVariables.PLAYER_VARIABLES).Enderchestst6);
			((Slot) _slots.get(6)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
	}
}
