package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PexplainComparatorProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The comparator is a tool of redstone witch helps you detecting the items than are in a tileentity block (chest, enderchest, barrel, ETC.) You can use it for technic faarms for example."),
					false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("You have to put the chest in the floor and put the dirt onto it. Then, in front of you put the comparator , the dust and the lamp, in this order. You look than the lamp is turn on."),
					false);
	}
}
