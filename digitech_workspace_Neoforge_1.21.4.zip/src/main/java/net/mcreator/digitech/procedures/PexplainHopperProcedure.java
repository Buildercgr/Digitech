package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PexplainHopperProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The hopper is very important in the world of redstone, it is used to transport blocks or items."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("La tolva es muy importante en el mundo de la redstone, sirve para transportar bloques o items."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(
					Component.literal("Put a chest on the ground and another three blocks high, now place the hoppers so that they are connected and put an item in the chest above. You will see that the item appears in the one below."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(
					Component.literal("Pon un cofre en el suelo y otro a tres bloques de alto, ahora coloca las tolvas de forma que queden comunicadas y pon alg\u00FAn item el el cofre de arriba. Ver\u00E1s que el item aparece en el de abajo. "),
					false);
	}
}
