package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class ZombieExplanationProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The zombie has 20 life points and has 3 melee attack points. Its weakness is health potions."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("El zombie tiene 20 puntos de vida y 3 puntos de ataque cuerpo a cuerpo. Su debilidad son las pociones de salud."), false);
	}
}
