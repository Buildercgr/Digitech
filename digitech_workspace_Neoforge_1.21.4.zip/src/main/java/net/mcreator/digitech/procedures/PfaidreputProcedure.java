package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.digitech.network.DigitechModVariables;

public class PfaidreputProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.faidallow = true;
			_vars.syncPlayerVariables(entity);
		}
	}
}
