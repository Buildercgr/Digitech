package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.digitech.network.DigitechModVariables;

public class PfinishTutProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Tut = false;
			_vars.syncPlayerVariables(entity);
		}
		if (entity instanceof Player _player)
			_player.closeContainer();
	}
}
