package net.mcreator.digitech.procedures;

import net.neoforged.neoforge.items.ItemHandlerHelper;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;

import net.mcreator.digitech.network.DigitechModVariables;
import net.mcreator.digitech.init.DigitechModGameRules;
import net.mcreator.digitech.DigitechMod;

public class FirstAidProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("You have to wait 50 seconds (Predeterminated). You can change it changing the ticks you have to wait in gamerule first aid cooldawn."), false);
		if (entity instanceof Player _player) {
			ItemStack _setstack = new ItemStack(Items.TOTEM_OF_UNDYING).copy();
			_setstack.setCount(1);
			ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
		}
		if (entity instanceof Player _player) {
			ItemStack _setstack = new ItemStack(Items.ENDER_PEARL).copy();
			_setstack.setCount(3);
			ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
		}
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Items gived correctly"), false);
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.faidallow = false;
			_vars.syncPlayerVariables(entity);
		}
		DigitechMod.queueServerWork((world instanceof ServerLevel _serverLevelGR4 ? _serverLevelGR4.getGameRules().getInt(DigitechModGameRules.FIRST_AID_COOLDAWN) : 0), () -> {
			PfaidreputProcedure.execute(entity);
		});
	}
}
