package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PPositiveFeedbackProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player)
			_player.closeContainer();
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("If you like this mod, please, let me know by a good comment or with an upvote or following it in Modrinth. You can prupose new ideas too and please, enjoy it."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Si te gusta este mod, d\u00E9jamelo saber siguiendolo o poniendo comentarios y, sobre todo, disfr\u00FAtalo."), false);
	}
}
