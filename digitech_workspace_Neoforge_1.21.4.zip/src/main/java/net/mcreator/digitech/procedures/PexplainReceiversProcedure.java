package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PexplainReceiversProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The receivers are the blocks that receive the signal. Each one has different behavior when the lit redstone reaches them."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Los receptores son los bloques que reciben la se\u00F1al. Cada uno tiene diferente comportamiento cuando llega la redstone encendida a ellos. "), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The main ones are: the piston, the lamp, the releaser, the dispenser and the target block."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Los principales son: el pist\u00F3n, la lampara, el soltador, el dispensador y el bloque diana."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Try what each one does."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Prueba t\u00FA que hacen cada uno."), false);
	}
}
