package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class SkeletonExplanationProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The skeleton has 16 life points. It also has 2 melee points and 4 ranged points. His weakness is wolves as they will attack him."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("El esqueleto tiene 16 puntos de vida. Tambi\u00E9n cuenta con 2 puntos cuerpo a cuerpo y 4 puntos a distancia. Su debilidad son los lobos, ya que lo atacar\u00E1n."), false);
	}
}
