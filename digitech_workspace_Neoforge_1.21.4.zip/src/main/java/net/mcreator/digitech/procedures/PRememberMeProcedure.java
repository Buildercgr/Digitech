package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.digitech.network.DigitechModVariables;

public class PRememberMeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.RemembMeInstalled = true;
			_vars.syncPlayerVariables(entity);
		}
	}
}
