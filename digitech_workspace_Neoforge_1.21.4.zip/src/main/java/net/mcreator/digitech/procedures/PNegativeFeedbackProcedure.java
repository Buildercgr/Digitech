package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PNegativeFeedbackProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player)
			_player.closeContainer();
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("If you don\u00B4t like this mod, please, say me the thinks that I can do better, maybe y can put it for the next update."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Si no te gusta, porfavor, hazme saber las cosas que puedo mejorar y quizas lo a\u00F1ada para la siguiente versi\u00F3n."), false);
	}
}
