package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class SlimeExplanationProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The slime has 16 health (Initially) and splits into smaller slimes when it takes damage. Its weakness is throwing health potions."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("El limo tiene 16 de salud (inicialmente) y se divide en limos m\u00E1s peque\u00F1os cuando recibe da\u00F1o. Su debilidad es lanzar pociones de salud."), false);
	}
}
