package net.mcreator.digitech.procedures;

import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Checkbox;

import net.mcreator.digitech.network.DigitechModVariables;

import java.util.HashMap;

public class PsetWifiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		String Name = "";
		String Password = "";
		boolean IsPasswordActivated = false;
		Name = guistate.containsKey("text:name") ? ((EditBox) guistate.get("text:name")).getValue() : "";
		Password = guistate.containsKey("text:password") ? ((EditBox) guistate.get("text:password")).getValue() : "";
		IsPasswordActivated = guistate.containsKey("checkbox:setpassword") && ((Checkbox) guistate.get("checkbox:setpassword")).selected();
		if (entity instanceof Player _player)
			_player.closeContainer();
		DigitechModVariables.WorldVariables.get(world).Wifi_Range = DigitechModVariables.WorldVariables.get(world).Wifi_Range + 1;
		DigitechModVariables.WorldVariables.get(world).syncData(world);
		{
			int _value = (int) DigitechModVariables.WorldVariables.get(world).Wifi_Range;
			BlockPos _pos = BlockPos.containing(x, y, z);
			BlockState _bs = world.getBlockState(_pos);
			if (_bs.getBlock().getStateDefinition().getProperty("wifi_range") instanceof IntegerProperty _integerProp && _integerProp.getPossibleValues().contains(_value))
				world.setBlock(_pos, _bs.setValue(_integerProp, _value), 3);
		}
		if (IsPasswordActivated) {
			DigitechModVariables.WorldVariables.get(world).Wifi = DigitechModVariables.WorldVariables.get(world).Wifi + "" + Name + ": " + Password + ", " + DigitechModVariables.WorldVariables.get(world).Wifi_Range + "; ";
			DigitechModVariables.WorldVariables.get(world).syncData(world);
		} else {
			DigitechModVariables.WorldVariables.get(world).Wifi = DigitechModVariables.WorldVariables.get(world).Wifi + "" + Name + ", " + DigitechModVariables.WorldVariables.get(world).Wifi_Range + "; ";
			DigitechModVariables.WorldVariables.get(world).syncData(world);
		}
	}
}
