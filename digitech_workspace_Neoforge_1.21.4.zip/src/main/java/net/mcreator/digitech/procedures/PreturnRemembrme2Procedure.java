package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.digitech.network.DigitechModVariables;

public class PreturnRemembrme2Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		boolean preturninstall = false;
		if (entity.getData(DigitechModVariables.PLAYER_VARIABLES).RemembMeInstalled == true) {
			preturninstall = false;
		} else {
			preturninstall = true;
		}
		return preturninstall;
	}
}
