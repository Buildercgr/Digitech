package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PexplainWikiProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The wiki option allows you to search help with any problem, if you are disorientated with Digitech you can go to the wiki, then click mobile button and you are here."), false);
	}
}
