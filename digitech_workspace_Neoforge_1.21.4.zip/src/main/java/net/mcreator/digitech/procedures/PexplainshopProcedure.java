package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class PexplainshopProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal(
					"In the mobile you can buy various things. The coin of all it is not the emerald, is DG (Digicoins). This coin is not a not legal divise, is only an in-game false coin without any economical prupose, only the prupose of get fun. With this coin you can buy items of the game."),
					false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("There are cards of 20, 40 and 60 DC. "), false);
	}
}
