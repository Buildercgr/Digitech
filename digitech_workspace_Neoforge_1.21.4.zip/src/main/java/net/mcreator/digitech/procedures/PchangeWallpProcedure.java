package net.mcreator.digitech.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.client.gui.components.Checkbox;

import java.util.HashMap;

public class PchangeWallpProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		if (guistate.containsKey("checkbox:LightMode") && ((Checkbox) guistate.get("checkbox:LightMode")).selected()) {
			Pwallpaper0Procedure.execute(world, x, y, z, entity);
		} else if (guistate.containsKey("checkbox:darkmode") && ((Checkbox) guistate.get("checkbox:darkmode")).selected()) {
			Pwallpaper1Procedure.execute(world, x, y, z, entity);
		} else if (guistate.containsKey("checkbox:sword") && ((Checkbox) guistate.get("checkbox:sword")).selected()) {
			Pwallpaper2Procedure.execute(world, x, y, z, entity);
		} else if (guistate.containsKey("checkbox:carrot") && ((Checkbox) guistate.get("checkbox:carrot")).selected()) {
			Pwallpaper3Procedure.execute(world, x, y, z, entity);
		} else if (guistate.containsKey("checkbox:buildercgr") && ((Checkbox) guistate.get("checkbox:buildercgr")).selected()) {
			Pwallpaper4Procedure.execute(entity);
		}
	}
}
