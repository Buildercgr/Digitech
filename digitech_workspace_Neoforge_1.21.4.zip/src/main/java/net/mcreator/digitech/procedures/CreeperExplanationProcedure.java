package net.mcreator.digitech.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class CreeperExplanationProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("The creeper is capable of exploding in your face. It has 7 health and 12 melee attack. I better tell you to kill him from a distance."), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("La enredadera es capaz de explotar en tu cara. Tiene 7 de salud y 12 de ataque cuerpo a cuerpo. Ser\u00E1 mejor que te diga que lo mates desde la distancia."), false);
	}
}
