package net.mcreator.digitech.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import net.mcreator.digitech.network.DigitechModVariables;

import java.util.function.Supplier;
import java.util.Map;

public class PkeependerchestProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchest0 = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(0)).getItem() : ItemStack.EMPTY).copy();
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchest1 = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(1)).getItem() : ItemStack.EMPTY).copy();
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchest2 = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(2)).getItem() : ItemStack.EMPTY).copy();
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchest3 = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(3)).getItem() : ItemStack.EMPTY).copy();
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchest4 = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(4)).getItem() : ItemStack.EMPTY).copy();
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchest5 = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(5)).getItem() : ItemStack.EMPTY).copy();
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchest6 = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(6)).getItem() : ItemStack.EMPTY).copy();
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchestst0 = getAmountInGUISlot(entity, 0);
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchestst1 = getAmountInGUISlot(entity, 1);
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchestst2 = getAmountInGUISlot(entity, 2);
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchestst3 = getAmountInGUISlot(entity, 3);
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchestst4 = getAmountInGUISlot(entity, 4);
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchestst5 = getAmountInGUISlot(entity, 5);
			_vars.syncPlayerVariables(entity);
		}
		{
			DigitechModVariables.PlayerVariables _vars = entity.getData(DigitechModVariables.PLAYER_VARIABLES);
			_vars.Enderchestst6 = getAmountInGUISlot(entity, 6);
			_vars.syncPlayerVariables(entity);
		}
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("Items keeped correctly."), true);
		if (entity instanceof ServerPlayer _player) {
			AdvancementHolder _adv = _player.server.getAdvancements().get(ResourceLocation.parse("digitech:keeping_items"));
			if (_adv != null) {
				AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
				if (!_ap.isDone()) {
					for (String criteria : _ap.getRemainingCriteria())
						_player.getAdvancements().award(_adv, criteria);
				}
			}
		}
	}

	private static int getAmountInGUISlot(Entity entity, int sltid) {
		if (entity instanceof Player player && player.containerMenu instanceof Supplier slotSupplier && slotSupplier.get() instanceof Map guiSlots) {
			ItemStack stack = ((Slot) guiSlots.get(sltid)).getItem();
			if (stack != null)
				return stack.getCount();
		}
		return 0;
	}
}
