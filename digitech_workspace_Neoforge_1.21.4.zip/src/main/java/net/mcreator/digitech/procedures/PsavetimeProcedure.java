package net.mcreator.digitech.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.client.gui.components.Checkbox;

import java.util.HashMap;

public class PsavetimeProcedure {
	public static void execute(LevelAccessor world, HashMap guistate) {
		if (guistate == null)
			return;
		if (guistate.containsKey("checkbox:sunrise") && ((Checkbox) guistate.get("checkbox:sunrise")).selected()) {
			PsunriseProcedure.execute(world);
		} else if (guistate.containsKey("checkbox:morning") && ((Checkbox) guistate.get("checkbox:morning")).selected()) {
			PdayProcedure.execute(world);
		} else if (guistate.containsKey("checkbox:afternoon") && ((Checkbox) guistate.get("checkbox:afternoon")).selected()) {
			PnoonProcedure.execute(world);
		} else if (guistate.containsKey("checkbox:sunset") && ((Checkbox) guistate.get("checkbox:sunset")).selected()) {
			PsunsetProcedure.execute(world);
		} else if (guistate.containsKey("checkbox:night") && ((Checkbox) guistate.get("checkbox:night")).selected()) {
			PnightProcedure.execute(world);
		}
	}
}
