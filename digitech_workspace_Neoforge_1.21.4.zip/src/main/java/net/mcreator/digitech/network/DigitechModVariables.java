package net.mcreator.digitech.network;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.common.util.INBTSerializable;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.HolderLookup;

import net.mcreator.digitech.DigitechMod;

import java.util.function.Supplier;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class DigitechModVariables {
	public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES = DeferredRegister.create(NeoForgeRegistries.Keys.ATTACHMENT_TYPES, DigitechMod.MODID);
	public static final Supplier<AttachmentType<PlayerVariables>> PLAYER_VARIABLES = ATTACHMENT_TYPES.register("player_variables", () -> AttachmentType.serializable(() -> new PlayerVariables()).build());

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		DigitechMod.addNetworkMessage(SavedDataSyncMessage.TYPE, SavedDataSyncMessage.STREAM_CODEC, SavedDataSyncMessage::handleData);
		DigitechMod.addNetworkMessage(PlayerVariablesSyncMessage.TYPE, PlayerVariablesSyncMessage.STREAM_CODEC, PlayerVariablesSyncMessage::handleData);
	}

	@EventBusSubscriber
	public static class EventBusVariableHandlers {
		@SubscribeEvent
		public static void onPlayerLoggedInSyncPlayerVariables(PlayerEvent.PlayerLoggedInEvent event) {
			if (event.getEntity() instanceof ServerPlayer player)
				player.getData(PLAYER_VARIABLES).syncPlayerVariables(event.getEntity());
		}

		@SubscribeEvent
		public static void onPlayerRespawnedSyncPlayerVariables(PlayerEvent.PlayerRespawnEvent event) {
			if (event.getEntity() instanceof ServerPlayer player)
				player.getData(PLAYER_VARIABLES).syncPlayerVariables(event.getEntity());
		}

		@SubscribeEvent
		public static void onPlayerChangedDimensionSyncPlayerVariables(PlayerEvent.PlayerChangedDimensionEvent event) {
			if (event.getEntity() instanceof ServerPlayer player)
				player.getData(PLAYER_VARIABLES).syncPlayerVariables(event.getEntity());
		}

		@SubscribeEvent
		public static void clonePlayer(PlayerEvent.Clone event) {
			PlayerVariables original = event.getOriginal().getData(PLAYER_VARIABLES);
			PlayerVariables clone = new PlayerVariables();
			clone.Wallpapers = original.Wallpapers;
			clone.Tut = original.Tut;
			clone.Enderchest0 = original.Enderchest0;
			clone.Enderchest1 = original.Enderchest1;
			clone.Enderchest2 = original.Enderchest2;
			clone.Enderchest3 = original.Enderchest3;
			clone.Enderchest4 = original.Enderchest4;
			clone.Enderchest5 = original.Enderchest5;
			clone.Enderchest6 = original.Enderchest6;
			clone.Enderchestst0 = original.Enderchestst0;
			clone.Enderchestst1 = original.Enderchestst1;
			clone.Enderchestst2 = original.Enderchestst2;
			clone.Enderchestst3 = original.Enderchestst3;
			clone.Enderchestst4 = original.Enderchestst4;
			clone.Enderchestst5 = original.Enderchestst5;
			clone.Enderchestst6 = original.Enderchestst6;
			clone.faidallow = original.faidallow;
			clone.RemembMeInstalled = original.RemembMeInstalled;
			if (!event.isWasDeath()) {
				clone.Waitremember = original.Waitremember;
				clone.wifi_connected = original.wifi_connected;
			}
			event.getEntity().setData(PLAYER_VARIABLES, clone);
		}

		@SubscribeEvent
		public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
			if (event.getEntity() instanceof ServerPlayer player) {
				SavedData mapdata = MapVariables.get(event.getEntity().level());
				SavedData worlddata = WorldVariables.get(event.getEntity().level());
				if (mapdata != null)
					PacketDistributor.sendToPlayer(player, new SavedDataSyncMessage(0, mapdata));
				if (worlddata != null)
					PacketDistributor.sendToPlayer(player, new SavedDataSyncMessage(1, worlddata));
			}
		}

		@SubscribeEvent
		public static void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
			if (event.getEntity() instanceof ServerPlayer player) {
				SavedData worlddata = WorldVariables.get(event.getEntity().level());
				if (worlddata != null)
					PacketDistributor.sendToPlayer(player, new SavedDataSyncMessage(1, worlddata));
			}
		}
	}

	public static class WorldVariables extends SavedData {
		public static final String DATA_NAME = "digitech_worldvars";
		public String Wifi = "\"\"";
		public double Wifi_Range = 0;

		public static WorldVariables load(CompoundTag tag, HolderLookup.Provider lookupProvider) {
			WorldVariables data = new WorldVariables();
			data.read(tag, lookupProvider);
			return data;
		}

		public void read(CompoundTag nbt, HolderLookup.Provider lookupProvider) {
			Wifi = nbt.getString("Wifi");
			Wifi_Range = nbt.getDouble("Wifi_Range");
		}

		@Override
		public CompoundTag save(CompoundTag nbt, HolderLookup.Provider lookupProvider) {
			nbt.putString("Wifi", Wifi);
			nbt.putDouble("Wifi_Range", Wifi_Range);
			return nbt;
		}

		public void syncData(LevelAccessor world) {
			this.setDirty();
			if (world instanceof ServerLevel level)
				PacketDistributor.sendToPlayersInDimension(level, new SavedDataSyncMessage(1, this));
		}

		static WorldVariables clientSide = new WorldVariables();

		public static WorldVariables get(LevelAccessor world) {
			if (world instanceof ServerLevel level) {
				return level.getDataStorage().computeIfAbsent(new SavedData.Factory<>(WorldVariables::new, WorldVariables::load), DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class MapVariables extends SavedData {
		public static final String DATA_NAME = "digitech_mapvars";

		public static MapVariables load(CompoundTag tag, HolderLookup.Provider lookupProvider) {
			MapVariables data = new MapVariables();
			data.read(tag, lookupProvider);
			return data;
		}

		public void read(CompoundTag nbt, HolderLookup.Provider lookupProvider) {
		}

		@Override
		public CompoundTag save(CompoundTag nbt, HolderLookup.Provider lookupProvider) {
			return nbt;
		}

		public void syncData(LevelAccessor world) {
			this.setDirty();
			if (world instanceof Level && !world.isClientSide())
				PacketDistributor.sendToAllPlayers(new SavedDataSyncMessage(0, this));
		}

		static MapVariables clientSide = new MapVariables();

		public static MapVariables get(LevelAccessor world) {
			if (world instanceof ServerLevelAccessor serverLevelAcc) {
				return serverLevelAcc.getLevel().getServer().getLevel(Level.OVERWORLD).getDataStorage().computeIfAbsent(new SavedData.Factory<>(MapVariables::new, MapVariables::load), DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public record SavedDataSyncMessage(int dataType, SavedData data) implements CustomPacketPayload {
		public static final Type<SavedDataSyncMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(DigitechMod.MODID, "saved_data_sync"));
		public static final StreamCodec<RegistryFriendlyByteBuf, SavedDataSyncMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, SavedDataSyncMessage message) -> {
			buffer.writeInt(message.dataType);
			if (message.data != null)
				buffer.writeNbt(message.data.save(new CompoundTag(), buffer.registryAccess()));
		}, (RegistryFriendlyByteBuf buffer) -> {
			int dataType = buffer.readInt();
			CompoundTag nbt = buffer.readNbt();
			SavedData data = null;
			if (nbt != null) {
				data = dataType == 0 ? new MapVariables() : new WorldVariables();
				if (data instanceof MapVariables mapVariables)
					mapVariables.read(nbt, buffer.registryAccess());
				else if (data instanceof WorldVariables worldVariables)
					worldVariables.read(nbt, buffer.registryAccess());
			}
			return new SavedDataSyncMessage(dataType, data);
		});

		@Override
		public Type<SavedDataSyncMessage> type() {
			return TYPE;
		}

		public static void handleData(final SavedDataSyncMessage message, final IPayloadContext context) {
			if (context.flow() == PacketFlow.CLIENTBOUND && message.data != null) {
				context.enqueueWork(() -> {
					if (message.dataType == 0)
						MapVariables.clientSide.read(message.data.save(new CompoundTag(), context.player().registryAccess()), context.player().registryAccess());
					else
						WorldVariables.clientSide.read(message.data.save(new CompoundTag(), context.player().registryAccess()), context.player().registryAccess());
				}).exceptionally(e -> {
					context.connection().disconnect(Component.literal(e.getMessage()));
					return null;
				});
			}
		}
	}

	public static class PlayerVariables implements INBTSerializable<CompoundTag> {
		public double Wallpapers = 0.0;
		public boolean Tut = true;
		public ItemStack Enderchest0 = ItemStack.EMPTY;
		public ItemStack Enderchest1 = ItemStack.EMPTY;
		public ItemStack Enderchest2 = ItemStack.EMPTY;
		public ItemStack Enderchest3 = ItemStack.EMPTY;
		public ItemStack Enderchest4 = ItemStack.EMPTY;
		public ItemStack Enderchest5 = ItemStack.EMPTY;
		public ItemStack Enderchest6 = ItemStack.EMPTY;
		public double Enderchestst0 = 0;
		public double Enderchestst1 = 0;
		public double Enderchestst2 = 0;
		public double Enderchestst3 = 0;
		public double Enderchestst4 = 0;
		public double Enderchestst5 = 0;
		public double Enderchestst6 = 0;
		public boolean faidallow = true;
		public boolean RemembMeInstalled = false;
		public String Waitremember = "\"\"";
		public boolean wifi_connected = false;

		@Override
		public CompoundTag serializeNBT(HolderLookup.Provider lookupProvider) {
			CompoundTag nbt = new CompoundTag();
			nbt.putDouble("Wallpapers", Wallpapers);
			nbt.putBoolean("Tut", Tut);
			nbt.put("Enderchest0", Enderchest0.saveOptional(lookupProvider));
			nbt.put("Enderchest1", Enderchest1.saveOptional(lookupProvider));
			nbt.put("Enderchest2", Enderchest2.saveOptional(lookupProvider));
			nbt.put("Enderchest3", Enderchest3.saveOptional(lookupProvider));
			nbt.put("Enderchest4", Enderchest4.saveOptional(lookupProvider));
			nbt.put("Enderchest5", Enderchest5.saveOptional(lookupProvider));
			nbt.put("Enderchest6", Enderchest6.saveOptional(lookupProvider));
			nbt.putDouble("Enderchestst0", Enderchestst0);
			nbt.putDouble("Enderchestst1", Enderchestst1);
			nbt.putDouble("Enderchestst2", Enderchestst2);
			nbt.putDouble("Enderchestst3", Enderchestst3);
			nbt.putDouble("Enderchestst4", Enderchestst4);
			nbt.putDouble("Enderchestst5", Enderchestst5);
			nbt.putDouble("Enderchestst6", Enderchestst6);
			nbt.putBoolean("faidallow", faidallow);
			nbt.putBoolean("RemembMeInstalled", RemembMeInstalled);
			nbt.putString("Waitremember", Waitremember);
			nbt.putBoolean("wifi_connected", wifi_connected);
			return nbt;
		}

		@Override
		public void deserializeNBT(HolderLookup.Provider lookupProvider, CompoundTag nbt) {
			Wallpapers = nbt.getDouble("Wallpapers");
			Tut = nbt.getBoolean("Tut");
			Enderchest0 = ItemStack.parseOptional(lookupProvider, nbt.getCompound("Enderchest0"));
			Enderchest1 = ItemStack.parseOptional(lookupProvider, nbt.getCompound("Enderchest1"));
			Enderchest2 = ItemStack.parseOptional(lookupProvider, nbt.getCompound("Enderchest2"));
			Enderchest3 = ItemStack.parseOptional(lookupProvider, nbt.getCompound("Enderchest3"));
			Enderchest4 = ItemStack.parseOptional(lookupProvider, nbt.getCompound("Enderchest4"));
			Enderchest5 = ItemStack.parseOptional(lookupProvider, nbt.getCompound("Enderchest5"));
			Enderchest6 = ItemStack.parseOptional(lookupProvider, nbt.getCompound("Enderchest6"));
			Enderchestst0 = nbt.getDouble("Enderchestst0");
			Enderchestst1 = nbt.getDouble("Enderchestst1");
			Enderchestst2 = nbt.getDouble("Enderchestst2");
			Enderchestst3 = nbt.getDouble("Enderchestst3");
			Enderchestst4 = nbt.getDouble("Enderchestst4");
			Enderchestst5 = nbt.getDouble("Enderchestst5");
			Enderchestst6 = nbt.getDouble("Enderchestst6");
			faidallow = nbt.getBoolean("faidallow");
			RemembMeInstalled = nbt.getBoolean("RemembMeInstalled");
			Waitremember = nbt.getString("Waitremember");
			wifi_connected = nbt.getBoolean("wifi_connected");
		}

		public void syncPlayerVariables(Entity entity) {
			if (entity instanceof ServerPlayer serverPlayer)
				PacketDistributor.sendToPlayer(serverPlayer, new PlayerVariablesSyncMessage(this));
		}
	}

	public record PlayerVariablesSyncMessage(PlayerVariables data) implements CustomPacketPayload {
		public static final Type<PlayerVariablesSyncMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(DigitechMod.MODID, "player_variables_sync"));
		public static final StreamCodec<RegistryFriendlyByteBuf, PlayerVariablesSyncMessage> STREAM_CODEC = StreamCodec
				.of((RegistryFriendlyByteBuf buffer, PlayerVariablesSyncMessage message) -> buffer.writeNbt(message.data().serializeNBT(buffer.registryAccess())), (RegistryFriendlyByteBuf buffer) -> {
					PlayerVariablesSyncMessage message = new PlayerVariablesSyncMessage(new PlayerVariables());
					message.data.deserializeNBT(buffer.registryAccess(), buffer.readNbt());
					return message;
				});

		@Override
		public Type<PlayerVariablesSyncMessage> type() {
			return TYPE;
		}

		public static void handleData(final PlayerVariablesSyncMessage message, final IPayloadContext context) {
			if (context.flow() == PacketFlow.CLIENTBOUND && message.data != null) {
				context.enqueueWork(() -> context.player().getData(PLAYER_VARIABLES).deserializeNBT(context.player().registryAccess(), message.data.serializeNBT(context.player().registryAccess()))).exceptionally(e -> {
					context.connection().disconnect(Component.literal(e.getMessage()));
					return null;
				});
			}
		}
	}
}
