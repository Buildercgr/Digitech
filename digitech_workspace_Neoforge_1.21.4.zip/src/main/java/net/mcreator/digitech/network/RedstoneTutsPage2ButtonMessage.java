
package net.mcreator.digitech.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.digitech.world.inventory.RedstoneTutsPage2Menu;
import net.mcreator.digitech.procedures.PopenRedstonemenuProcedure;
import net.mcreator.digitech.procedures.PfinalistationProcedure;
import net.mcreator.digitech.procedures.PexplainVerticalTransmissionProcedure;
import net.mcreator.digitech.procedures.PexplainReceiversProcedure;
import net.mcreator.digitech.procedures.PexplainPressionProcedure;
import net.mcreator.digitech.procedures.PexplainHopperProcedure;
import net.mcreator.digitech.procedures.PScreenProcedure;
import net.mcreator.digitech.DigitechMod;

import java.util.HashMap;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public record RedstoneTutsPage2ButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {

	public static final Type<RedstoneTutsPage2ButtonMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(DigitechMod.MODID, "redstone_tuts_page_2_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, RedstoneTutsPage2ButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, RedstoneTutsPage2ButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new RedstoneTutsPage2ButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));
	@Override
	public Type<RedstoneTutsPage2ButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final RedstoneTutsPage2ButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> {
				Player entity = context.player();
				int buttonID = message.buttonID;
				int x = message.x;
				int y = message.y;
				int z = message.z;
				handleButtonAction(entity, buttonID, x, y, z);
			}).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		HashMap guistate = RedstoneTutsPage2Menu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			PexplainReceiversProcedure.execute(entity);
		}
		if (buttonID == 1) {

			PexplainPressionProcedure.execute(entity);
		}
		if (buttonID == 2) {

			PexplainVerticalTransmissionProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 3) {

			PexplainHopperProcedure.execute(entity);
		}
		if (buttonID == 4) {

			PfinalistationProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 5) {

			PScreenProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 6) {

			PopenRedstonemenuProcedure.execute(world, x, y, z, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		DigitechMod.addNetworkMessage(RedstoneTutsPage2ButtonMessage.TYPE, RedstoneTutsPage2ButtonMessage.STREAM_CODEC, RedstoneTutsPage2ButtonMessage::handleData);
	}
}
