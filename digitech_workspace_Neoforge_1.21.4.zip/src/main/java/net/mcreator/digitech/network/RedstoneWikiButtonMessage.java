
package net.mcreator.digitech.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.digitech.world.inventory.RedstoneWikiMenu;
import net.mcreator.digitech.procedures.PopenRedstonemenuProcedure;
import net.mcreator.digitech.procedures.PopenMediumredstoneMenuProcedure;
import net.mcreator.digitech.procedures.PopenGUIerrorDevelopingProcedure;
import net.mcreator.digitech.procedures.PScreenProcedure;
import net.mcreator.digitech.DigitechMod;

import java.util.HashMap;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public record RedstoneWikiButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {

	public static final Type<RedstoneWikiButtonMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(DigitechMod.MODID, "redstone_wiki_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, RedstoneWikiButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, RedstoneWikiButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new RedstoneWikiButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));
	@Override
	public Type<RedstoneWikiButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final RedstoneWikiButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> {
				Player entity = context.player();
				int buttonID = message.buttonID;
				int x = message.x;
				int y = message.y;
				int z = message.z;
				handleButtonAction(entity, buttonID, x, y, z);
			}).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		HashMap guistate = RedstoneWikiMenu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			PopenRedstonemenuProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 1) {

			PopenMediumredstoneMenuProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 2) {

			PopenGUIerrorDevelopingProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 3) {

			PScreenProcedure.execute(world, x, y, z, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		DigitechMod.addNetworkMessage(RedstoneWikiButtonMessage.TYPE, RedstoneWikiButtonMessage.STREAM_CODEC, RedstoneWikiButtonMessage::handleData);
	}
}
