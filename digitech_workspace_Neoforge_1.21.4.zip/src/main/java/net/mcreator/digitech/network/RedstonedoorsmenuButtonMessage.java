
package net.mcreator.digitech.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.digitech.world.inventory.RedstonedoorsmenuMenu;
import net.mcreator.digitech.procedures.PexplainORDoorProcedure;
import net.mcreator.digitech.procedures.PexplainNOTDoorProcedure;
import net.mcreator.digitech.procedures.PexplainNORDoorProcedure;
import net.mcreator.digitech.procedures.PScreenProcedure;
import net.mcreator.digitech.procedures.PExplainANDDoorProcedure;
import net.mcreator.digitech.DigitechMod;

import java.util.HashMap;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public record RedstonedoorsmenuButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {

	public static final Type<RedstonedoorsmenuButtonMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(DigitechMod.MODID, "redstonedoorsmenu_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, RedstonedoorsmenuButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, RedstonedoorsmenuButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new RedstonedoorsmenuButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));
	@Override
	public Type<RedstonedoorsmenuButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final RedstonedoorsmenuButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> {
				Player entity = context.player();
				int buttonID = message.buttonID;
				int x = message.x;
				int y = message.y;
				int z = message.z;
				handleButtonAction(entity, buttonID, x, y, z);
			}).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		HashMap guistate = RedstonedoorsmenuMenu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			PexplainNOTDoorProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 1) {

			PexplainORDoorProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 2) {

			PexplainNORDoorProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 3) {

			PExplainANDDoorProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 4) {

			PScreenProcedure.execute(world, x, y, z, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		DigitechMod.addNetworkMessage(RedstonedoorsmenuButtonMessage.TYPE, RedstonedoorsmenuButtonMessage.STREAM_CODEC, RedstonedoorsmenuButtonMessage::handleData);
	}
}
