
package net.mcreator.digitech.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.digitech.world.inventory.WikiMenu;
import net.mcreator.digitech.procedures.PwevwikiProcedure;
import net.mcreator.digitech.procedures.PopenWikiMCProcedure;
import net.mcreator.digitech.procedures.PopenPhoneWikiProcedure;
import net.mcreator.digitech.procedures.PScreenProcedure;
import net.mcreator.digitech.DigitechMod;

import java.util.HashMap;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public record WikiButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {

	public static final Type<WikiButtonMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(DigitechMod.MODID, "wiki_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, WikiButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, WikiButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new WikiButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));
	@Override
	public Type<WikiButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final WikiButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> {
				Player entity = context.player();
				int buttonID = message.buttonID;
				int x = message.x;
				int y = message.y;
				int z = message.z;
				handleButtonAction(entity, buttonID, x, y, z);
			}).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		HashMap guistate = WikiMenu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			PwevwikiProcedure.execute(entity);
		}
		if (buttonID == 1) {

			PopenPhoneWikiProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 2) {

			PopenWikiMCProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 3) {

			PScreenProcedure.execute(world, x, y, z, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		DigitechMod.addNetworkMessage(WikiButtonMessage.TYPE, WikiButtonMessage.STREAM_CODEC, WikiButtonMessage::handleData);
	}
}
