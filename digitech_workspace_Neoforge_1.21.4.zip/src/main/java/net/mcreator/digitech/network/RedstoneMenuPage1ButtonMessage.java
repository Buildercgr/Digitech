
package net.mcreator.digitech.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.digitech.world.inventory.RedstoneMenuPage1Menu;
import net.mcreator.digitech.procedures.PwelcomeRedstoneWikiProcedure;
import net.mcreator.digitech.procedures.PopenRedstoneMenu2Procedure;
import net.mcreator.digitech.procedures.PexplainRepeaterProcedure;
import net.mcreator.digitech.procedures.PexplainGeneratorProcedure;
import net.mcreator.digitech.procedures.PexplainComparatorProcedure;
import net.mcreator.digitech.procedures.PScreenProcedure;
import net.mcreator.digitech.procedures.PExplainRedstoneDustProcedure;
import net.mcreator.digitech.DigitechMod;

import java.util.HashMap;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public record RedstoneMenuPage1ButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {

	public static final Type<RedstoneMenuPage1ButtonMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(DigitechMod.MODID, "redstone_menu_page_1_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, RedstoneMenuPage1ButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, RedstoneMenuPage1ButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new RedstoneMenuPage1ButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));
	@Override
	public Type<RedstoneMenuPage1ButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final RedstoneMenuPage1ButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> {
				Player entity = context.player();
				int buttonID = message.buttonID;
				int x = message.x;
				int y = message.y;
				int z = message.z;
				handleButtonAction(entity, buttonID, x, y, z);
			}).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		HashMap guistate = RedstoneMenuPage1Menu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			PwelcomeRedstoneWikiProcedure.execute(entity);
		}
		if (buttonID == 1) {

			PExplainRedstoneDustProcedure.execute(entity);
		}
		if (buttonID == 2) {

			PexplainRepeaterProcedure.execute(entity);
		}
		if (buttonID == 3) {

			PexplainComparatorProcedure.execute(entity);
		}
		if (buttonID == 4) {

			PexplainGeneratorProcedure.execute(entity);
		}
		if (buttonID == 5) {

			PScreenProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 6) {

			PopenRedstoneMenu2Procedure.execute(world, x, y, z, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		DigitechMod.addNetworkMessage(RedstoneMenuPage1ButtonMessage.TYPE, RedstoneMenuPage1ButtonMessage.STREAM_CODEC, RedstoneMenuPage1ButtonMessage::handleData);
	}
}
