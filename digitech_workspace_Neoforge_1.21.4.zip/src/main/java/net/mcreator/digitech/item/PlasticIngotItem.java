
package net.mcreator.digitech.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PlasticIngotItem extends Item {
	public PlasticIngotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.COMMON).stacksTo(64));
	}
}
