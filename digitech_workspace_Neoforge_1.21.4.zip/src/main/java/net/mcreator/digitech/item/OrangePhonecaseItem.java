
package net.mcreator.digitech.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;

import net.mcreator.digitech.procedures.PutOrangeCaseProcedure;

public class OrangePhonecaseItem extends Item {
	public OrangePhonecaseItem(Item.Properties properties) {
		super(properties.rarity(Rarity.COMMON).stacksTo(1));
	}

	@Override
	public InteractionResult use(Level world, Player entity, InteractionHand hand) {
		InteractionResult ar = super.use(world, entity, hand);
		PutOrangeCaseProcedure.execute(entity);
		return ar;
	}
}
