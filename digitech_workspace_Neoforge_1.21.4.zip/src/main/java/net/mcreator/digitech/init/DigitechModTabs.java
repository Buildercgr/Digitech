
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.digitech.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.digitech.DigitechMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class DigitechModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DigitechMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> THECNOLOGY = REGISTRY.register("thecnology",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.digitech.thecnology")).icon(() -> new ItemStack(DigitechModItems.MICRO_CHIP_DUST.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DigitechModItems.MICRO_CHIP_DUST.get());
				tabData.accept(DigitechModItems.PLASTIC_INGOT.get());
				tabData.accept(DigitechModBlocks.WIFI.get().asItem());
				tabData.accept(DigitechModBlocks.PC.get().asItem());
				tabData.accept(DigitechModItems.MOBILE.get());
				tabData.accept(DigitechModItems.CARD.get());
				tabData.accept(DigitechModItems.TWENTY_D_CCHECK.get());
				tabData.accept(DigitechModItems.FORTYDCCHECK.get());
				tabData.accept(DigitechModItems.SIXTY_D_CCHECK.get());
				tabData.accept(DigitechModItems.REDCASE.get());
				tabData.accept(DigitechModItems.BLUECASE.get());
				tabData.accept(DigitechModItems.GREENCASE.get());
				tabData.accept(DigitechModItems.YELLOW_PHONECASE.get());
				tabData.accept(DigitechModItems.PURPLE_PHONECASE.get());
				tabData.accept(DigitechModItems.ORANGE_PHONECASE.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(DigitechModItems.MICRO_CHIP_DUST.get());
			tabData.accept(DigitechModItems.PLASTIC_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(DigitechModBlocks.MICRO_CHIP_ORE.get().asItem());
			tabData.accept(DigitechModBlocks.MICRO_CHIP_BLOCK.get().asItem());
			tabData.accept(DigitechModBlocks.PLASTIC_ORE.get().asItem());
			tabData.accept(DigitechModBlocks.PLASTIC_BLOCK.get().asItem());
		}
	}
}
