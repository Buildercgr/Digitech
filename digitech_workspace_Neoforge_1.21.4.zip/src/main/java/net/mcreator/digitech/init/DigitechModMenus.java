
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.digitech.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import net.mcreator.digitech.world.inventory.WithoutconnexionMenu;
import net.mcreator.digitech.world.inventory.WikiMenu;
import net.mcreator.digitech.world.inventory.ShopMenu;
import net.mcreator.digitech.world.inventory.ShopGUIMenu;
import net.mcreator.digitech.world.inventory.Shop2Menu;
import net.mcreator.digitech.world.inventory.SettingsGuiMenu;
import net.mcreator.digitech.world.inventory.SetWifiMenu;
import net.mcreator.digitech.world.inventory.SetWifiGUIMenu;
import net.mcreator.digitech.world.inventory.SetPhoneMenu;
import net.mcreator.digitech.world.inventory.SetModeMCMenu;
import net.mcreator.digitech.world.inventory.SetMCMenu;
import net.mcreator.digitech.world.inventory.RememberMeMenu;
import net.mcreator.digitech.world.inventory.RedstonedoorsmenuMenu;
import net.mcreator.digitech.world.inventory.RedstoneWikiMenu;
import net.mcreator.digitech.world.inventory.RedstoneTutsPage2Menu;
import net.mcreator.digitech.world.inventory.RedstoneMenuPage1Menu;
import net.mcreator.digitech.world.inventory.RedstoneMediumTutsMenu;
import net.mcreator.digitech.world.inventory.MobileWikiMenu;
import net.mcreator.digitech.world.inventory.MinecraftwikiENMenu;
import net.mcreator.digitech.world.inventory.MenuPulseMenu;
import net.mcreator.digitech.world.inventory.InicioScreen4Menu;
import net.mcreator.digitech.world.inventory.InicioScreen3Menu;
import net.mcreator.digitech.world.inventory.InicioScreen2Menu;
import net.mcreator.digitech.world.inventory.InicioScreen1Menu;
import net.mcreator.digitech.world.inventory.HomeGUIMenu;
import net.mcreator.digitech.world.inventory.GUIErrorDevelopingMenu;
import net.mcreator.digitech.world.inventory.ExampleVerticalTransmissionMenu;
import net.mcreator.digitech.world.inventory.ExamplePulseLimitatorMenu;
import net.mcreator.digitech.world.inventory.ExamplePulseGeneratorMenu;
import net.mcreator.digitech.world.inventory.ExamplePulseExpansorMenu;
import net.mcreator.digitech.world.inventory.ExampleORDoorMenu;
import net.mcreator.digitech.world.inventory.ExampleNotDoorMenu;
import net.mcreator.digitech.world.inventory.ExampleNORDoorMenu;
import net.mcreator.digitech.world.inventory.ExampleClockMenu;
import net.mcreator.digitech.world.inventory.Example2AndDoorMenu;
import net.mcreator.digitech.world.inventory.Example1AndDoorMenu;
import net.mcreator.digitech.world.inventory.EnderchestMenu;
import net.mcreator.digitech.world.inventory.CombatWikiMenu;
import net.mcreator.digitech.DigitechMod;

public class DigitechModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, DigitechMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<WikiMenu>> WIKI = REGISTRY.register("wiki", () -> IMenuTypeExtension.create(WikiMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<MobileWikiMenu>> MOBILE_WIKI = REGISTRY.register("mobile_wiki", () -> IMenuTypeExtension.create(MobileWikiMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<InicioScreen1Menu>> INICIO_SCREEN_1 = REGISTRY.register("inicio_screen_1", () -> IMenuTypeExtension.create(InicioScreen1Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<InicioScreen2Menu>> INICIO_SCREEN_2 = REGISTRY.register("inicio_screen_2", () -> IMenuTypeExtension.create(InicioScreen2Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<InicioScreen3Menu>> INICIO_SCREEN_3 = REGISTRY.register("inicio_screen_3", () -> IMenuTypeExtension.create(InicioScreen3Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<InicioScreen4Menu>> INICIO_SCREEN_4 = REGISTRY.register("inicio_screen_4", () -> IMenuTypeExtension.create(InicioScreen4Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Shop2Menu>> SHOP_2 = REGISTRY.register("shop_2", () -> IMenuTypeExtension.create(Shop2Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<WithoutconnexionMenu>> WITHOUTCONNEXION = REGISTRY.register("withoutconnexion", () -> IMenuTypeExtension.create(WithoutconnexionMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<SetWifiMenu>> SET_WIFI = REGISTRY.register("set_wifi", () -> IMenuTypeExtension.create(SetWifiMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<SetMCMenu>> SET_MC = REGISTRY.register("set_mc", () -> IMenuTypeExtension.create(SetMCMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<SetModeMCMenu>> SET_MODE_MC = REGISTRY.register("set_mode_mc", () -> IMenuTypeExtension.create(SetModeMCMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ShopGUIMenu>> SHOP_GUI = REGISTRY.register("shop_gui", () -> IMenuTypeExtension.create(ShopGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<RememberMeMenu>> REMEMBER_ME = REGISTRY.register("remember_me", () -> IMenuTypeExtension.create(RememberMeMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ShopMenu>> SHOP = REGISTRY.register("shop", () -> IMenuTypeExtension.create(ShopMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<MinecraftwikiENMenu>> MINECRAFTWIKI_EN = REGISTRY.register("minecraftwiki_en", () -> IMenuTypeExtension.create(MinecraftwikiENMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<RedstoneTutsPage2Menu>> REDSTONE_TUTS_PAGE_2 = REGISTRY.register("redstone_tuts_page_2", () -> IMenuTypeExtension.create(RedstoneTutsPage2Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<RedstoneWikiMenu>> REDSTONE_WIKI = REGISTRY.register("redstone_wiki", () -> IMenuTypeExtension.create(RedstoneWikiMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<RedstoneMenuPage1Menu>> REDSTONE_MENU_PAGE_1 = REGISTRY.register("redstone_menu_page_1", () -> IMenuTypeExtension.create(RedstoneMenuPage1Menu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ExampleVerticalTransmissionMenu>> EXAMPLE_VERTICAL_TRANSMISSION = REGISTRY.register("example_vertical_transmission", () -> IMenuTypeExtension.create(ExampleVerticalTransmissionMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<RedstoneMediumTutsMenu>> REDSTONE_MEDIUM_TUTS = REGISTRY.register("redstone_medium_tuts", () -> IMenuTypeExtension.create(RedstoneMediumTutsMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ExampleClockMenu>> EXAMPLE_CLOCK = REGISTRY.register("example_clock", () -> IMenuTypeExtension.create(ExampleClockMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ExamplePulseGeneratorMenu>> EXAMPLE_PULSE_GENERATOR = REGISTRY.register("example_pulse_generator", () -> IMenuTypeExtension.create(ExamplePulseGeneratorMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<GUIErrorDevelopingMenu>> GUI_ERROR_DEVELOPING = REGISTRY.register("gui_error_developing", () -> IMenuTypeExtension.create(GUIErrorDevelopingMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ExamplePulseExpansorMenu>> EXAMPLE_PULSE_EXPANSOR = REGISTRY.register("example_pulse_expansor", () -> IMenuTypeExtension.create(ExamplePulseExpansorMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ExamplePulseLimitatorMenu>> EXAMPLE_PULSE_LIMITATOR = REGISTRY.register("example_pulse_limitator", () -> IMenuTypeExtension.create(ExamplePulseLimitatorMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<RedstonedoorsmenuMenu>> REDSTONEDOORSMENU = REGISTRY.register("redstonedoorsmenu", () -> IMenuTypeExtension.create(RedstonedoorsmenuMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ExampleNotDoorMenu>> EXAMPLE_NOT_DOOR = REGISTRY.register("example_not_door", () -> IMenuTypeExtension.create(ExampleNotDoorMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ExampleORDoorMenu>> EXAMPLE_OR_DOOR = REGISTRY.register("example_or_door", () -> IMenuTypeExtension.create(ExampleORDoorMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ExampleNORDoorMenu>> EXAMPLE_NOR_DOOR = REGISTRY.register("example_nor_door", () -> IMenuTypeExtension.create(ExampleNORDoorMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Example1AndDoorMenu>> EXAMPLE_1_AND_DOOR = REGISTRY.register("example_1_and_door", () -> IMenuTypeExtension.create(Example1AndDoorMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<Example2AndDoorMenu>> EXAMPLE_2_AND_DOOR = REGISTRY.register("example_2_and_door", () -> IMenuTypeExtension.create(Example2AndDoorMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<SettingsGuiMenu>> SETTINGS_GUI = REGISTRY.register("settings_gui", () -> IMenuTypeExtension.create(SettingsGuiMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<SetPhoneMenu>> SET_PHONE = REGISTRY.register("set_phone", () -> IMenuTypeExtension.create(SetPhoneMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<CombatWikiMenu>> COMBAT_WIKI = REGISTRY.register("combat_wiki", () -> IMenuTypeExtension.create(CombatWikiMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<HomeGUIMenu>> HOME_GUI = REGISTRY.register("home_gui", () -> IMenuTypeExtension.create(HomeGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<EnderchestMenu>> ENDERCHEST = REGISTRY.register("enderchest", () -> IMenuTypeExtension.create(EnderchestMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<MenuPulseMenu>> MENU_PULSE = REGISTRY.register("menu_pulse", () -> IMenuTypeExtension.create(MenuPulseMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<SetWifiGUIMenu>> SET_WIFI_GUI = REGISTRY.register("set_wifi_gui", () -> IMenuTypeExtension.create(SetWifiGUIMenu::new));
}
