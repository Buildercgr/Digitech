
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.digitech.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.GameRules;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class DigitechModGameRules {
	public static GameRules.Key<GameRules.IntegerValue> FIRST_AID_COOLDAWN;

	@SubscribeEvent
	public static void registerGameRules(FMLCommonSetupEvent event) {
		FIRST_AID_COOLDAWN = GameRules.register("firstAidCooldawn", GameRules.Category.PLAYER, GameRules.IntegerValue.create(1000));
	}
}
