
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.digitech.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.digitech.item.YellowPhonecaseItem;
import net.mcreator.digitech.item.YellowPhoneItem;
import net.mcreator.digitech.item.TwentyDCcheckItem;
import net.mcreator.digitech.item.SixtyDCcheckItem;
import net.mcreator.digitech.item.RedmobileItem;
import net.mcreator.digitech.item.RedcaseItem;
import net.mcreator.digitech.item.PurplePhonecaseItem;
import net.mcreator.digitech.item.PurplePhoneItem;
import net.mcreator.digitech.item.PlasticIngotItem;
import net.mcreator.digitech.item.OrangePhonecaseItem;
import net.mcreator.digitech.item.OrangePhoneItem;
import net.mcreator.digitech.item.MobileItem;
import net.mcreator.digitech.item.MicroChipDustItem;
import net.mcreator.digitech.item.GreenmobileItem;
import net.mcreator.digitech.item.GreencaseItem;
import net.mcreator.digitech.item.FortydccheckItem;
import net.mcreator.digitech.item.CardItem;
import net.mcreator.digitech.item.BluemobileItem;
import net.mcreator.digitech.item.BluecaseItem;
import net.mcreator.digitech.DigitechMod;

import java.util.function.Function;

public class DigitechModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(DigitechMod.MODID);
	public static final DeferredItem<Item> MICRO_CHIP_DUST = register("micro_chip_dust", MicroChipDustItem::new);
	public static final DeferredItem<Item> MICRO_CHIP_ORE = block(DigitechModBlocks.MICRO_CHIP_ORE);
	public static final DeferredItem<Item> MICRO_CHIP_BLOCK = block(DigitechModBlocks.MICRO_CHIP_BLOCK);
	public static final DeferredItem<Item> MOBILE = register("mobile", MobileItem::new);
	public static final DeferredItem<Item> PLASTIC_INGOT = register("plastic_ingot", PlasticIngotItem::new);
	public static final DeferredItem<Item> PLASTIC_ORE = block(DigitechModBlocks.PLASTIC_ORE);
	public static final DeferredItem<Item> PLASTIC_BLOCK = block(DigitechModBlocks.PLASTIC_BLOCK);
	public static final DeferredItem<Item> PC = block(DigitechModBlocks.PC);
	public static final DeferredItem<Item> TWENTY_D_CCHECK = register("twenty_d_ccheck", TwentyDCcheckItem::new);
	public static final DeferredItem<Item> FORTYDCCHECK = register("fortydccheck", FortydccheckItem::new);
	public static final DeferredItem<Item> SIXTY_D_CCHECK = register("sixty_d_ccheck", SixtyDCcheckItem::new);
	public static final DeferredItem<Item> BLUEMOBILE = register("bluemobile", BluemobileItem::new);
	public static final DeferredItem<Item> REDCASE = register("redcase", RedcaseItem::new);
	public static final DeferredItem<Item> REDMOBILE = register("redmobile", RedmobileItem::new);
	public static final DeferredItem<Item> GREENCASE = register("greencase", GreencaseItem::new);
	public static final DeferredItem<Item> GREENMOBILE = register("greenmobile", GreenmobileItem::new);
	public static final DeferredItem<Item> BLUECASE = register("bluecase", BluecaseItem::new);
	public static final DeferredItem<Item> WIFI = block(DigitechModBlocks.WIFI);
	public static final DeferredItem<Item> YELLOW_PHONECASE = register("yellow_phonecase", YellowPhonecaseItem::new);
	public static final DeferredItem<Item> YELLOW_PHONE = register("yellow_phone", YellowPhoneItem::new);
	public static final DeferredItem<Item> PURPLE_PHONE = register("purple_phone", PurplePhoneItem::new);
	public static final DeferredItem<Item> ORANGE_PHONE = register("orange_phone", OrangePhoneItem::new);
	public static final DeferredItem<Item> PURPLE_PHONECASE = register("purple_phonecase", PurplePhonecaseItem::new);
	public static final DeferredItem<Item> ORANGE_PHONECASE = register("orange_phonecase", OrangePhonecaseItem::new);
	public static final DeferredItem<Item> CARD = register("card", CardItem::new);
	public static final DeferredItem<Item> SECURITY_CAMERA = block(DigitechModBlocks.SECURITY_CAMERA);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
