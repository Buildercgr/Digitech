
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.digitech.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.digitech.block.WifiBlock;
import net.mcreator.digitech.block.PlasticOreBlock;
import net.mcreator.digitech.block.PlasticBlockBlock;
import net.mcreator.digitech.block.PCBlock;
import net.mcreator.digitech.block.MicroChipOreBlock;
import net.mcreator.digitech.block.MicroChipBlockBlock;
import net.mcreator.digitech.DigitechMod;

import java.util.function.Function;

public class DigitechModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(DigitechMod.MODID);
	public static final DeferredBlock<Block> MICRO_CHIP_ORE = register("micro_chip_ore", MicroChipOreBlock::new);
	public static final DeferredBlock<Block> MICRO_CHIP_BLOCK = register("micro_chip_block", MicroChipBlockBlock::new);
	public static final DeferredBlock<Block> PLASTIC_ORE = register("plastic_ore", PlasticOreBlock::new);
	public static final DeferredBlock<Block> PLASTIC_BLOCK = register("plastic_block", PlasticBlockBlock::new);
	public static final DeferredBlock<Block> PC = register("pc", PCBlock::new);
	public static final DeferredBlock<Block> WIFI = register("wifi", WifiBlock::new);
	public static final DeferredBlock<Block> SECURITY_CAMERA = register("security_camera", SecurityCameraBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}
