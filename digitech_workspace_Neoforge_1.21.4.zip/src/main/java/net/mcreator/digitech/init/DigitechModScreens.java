
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.digitech.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.digitech.client.gui.WithoutconnexionScreen;
import net.mcreator.digitech.client.gui.WikiScreen;
import net.mcreator.digitech.client.gui.ShopScreen;
import net.mcreator.digitech.client.gui.ShopGUIScreen;
import net.mcreator.digitech.client.gui.Shop2Screen;
import net.mcreator.digitech.client.gui.SettingsGuiScreen;
import net.mcreator.digitech.client.gui.SetWifiScreen;
import net.mcreator.digitech.client.gui.SetWifiGUIScreen;
import net.mcreator.digitech.client.gui.SetPhoneScreen;
import net.mcreator.digitech.client.gui.SetModeMCScreen;
import net.mcreator.digitech.client.gui.SetMCScreen;
import net.mcreator.digitech.client.gui.RememberMeScreen;
import net.mcreator.digitech.client.gui.RedstonedoorsmenuScreen;
import net.mcreator.digitech.client.gui.RedstoneWikiScreen;
import net.mcreator.digitech.client.gui.RedstoneTutsPage2Screen;
import net.mcreator.digitech.client.gui.RedstoneMenuPage1Screen;
import net.mcreator.digitech.client.gui.RedstoneMediumTutsScreen;
import net.mcreator.digitech.client.gui.MobileWikiScreen;
import net.mcreator.digitech.client.gui.MinecraftwikiENScreen;
import net.mcreator.digitech.client.gui.MenuPulseScreen;
import net.mcreator.digitech.client.gui.InicioScreen4Screen;
import net.mcreator.digitech.client.gui.InicioScreen3Screen;
import net.mcreator.digitech.client.gui.InicioScreen2Screen;
import net.mcreator.digitech.client.gui.InicioScreen1Screen;
import net.mcreator.digitech.client.gui.HomeGUIScreen;
import net.mcreator.digitech.client.gui.GUIErrorDevelopingScreen;
import net.mcreator.digitech.client.gui.ExampleVerticalTransmissionScreen;
import net.mcreator.digitech.client.gui.ExamplePulseLimitatorScreen;
import net.mcreator.digitech.client.gui.ExamplePulseGeneratorScreen;
import net.mcreator.digitech.client.gui.ExamplePulseExpansorScreen;
import net.mcreator.digitech.client.gui.ExampleORDoorScreen;
import net.mcreator.digitech.client.gui.ExampleNotDoorScreen;
import net.mcreator.digitech.client.gui.ExampleNORDoorScreen;
import net.mcreator.digitech.client.gui.ExampleClockScreen;
import net.mcreator.digitech.client.gui.Example2AndDoorScreen;
import net.mcreator.digitech.client.gui.Example1AndDoorScreen;
import net.mcreator.digitech.client.gui.EnderchestScreen;
import net.mcreator.digitech.client.gui.CombatWikiScreen;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class DigitechModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(DigitechModMenus.WIKI.get(), WikiScreen::new);
		event.register(DigitechModMenus.MOBILE_WIKI.get(), MobileWikiScreen::new);
		event.register(DigitechModMenus.INICIO_SCREEN_1.get(), InicioScreen1Screen::new);
		event.register(DigitechModMenus.INICIO_SCREEN_2.get(), InicioScreen2Screen::new);
		event.register(DigitechModMenus.INICIO_SCREEN_3.get(), InicioScreen3Screen::new);
		event.register(DigitechModMenus.INICIO_SCREEN_4.get(), InicioScreen4Screen::new);
		event.register(DigitechModMenus.SHOP_2.get(), Shop2Screen::new);
		event.register(DigitechModMenus.WITHOUTCONNEXION.get(), WithoutconnexionScreen::new);
		event.register(DigitechModMenus.SET_WIFI.get(), SetWifiScreen::new);
		event.register(DigitechModMenus.SET_MC.get(), SetMCScreen::new);
		event.register(DigitechModMenus.SET_MODE_MC.get(), SetModeMCScreen::new);
		event.register(DigitechModMenus.SHOP_GUI.get(), ShopGUIScreen::new);
		event.register(DigitechModMenus.REMEMBER_ME.get(), RememberMeScreen::new);
		event.register(DigitechModMenus.SHOP.get(), ShopScreen::new);
		event.register(DigitechModMenus.MINECRAFTWIKI_EN.get(), MinecraftwikiENScreen::new);
		event.register(DigitechModMenus.REDSTONE_TUTS_PAGE_2.get(), RedstoneTutsPage2Screen::new);
		event.register(DigitechModMenus.REDSTONE_WIKI.get(), RedstoneWikiScreen::new);
		event.register(DigitechModMenus.REDSTONE_MENU_PAGE_1.get(), RedstoneMenuPage1Screen::new);
		event.register(DigitechModMenus.EXAMPLE_VERTICAL_TRANSMISSION.get(), ExampleVerticalTransmissionScreen::new);
		event.register(DigitechModMenus.REDSTONE_MEDIUM_TUTS.get(), RedstoneMediumTutsScreen::new);
		event.register(DigitechModMenus.EXAMPLE_CLOCK.get(), ExampleClockScreen::new);
		event.register(DigitechModMenus.EXAMPLE_PULSE_GENERATOR.get(), ExamplePulseGeneratorScreen::new);
		event.register(DigitechModMenus.GUI_ERROR_DEVELOPING.get(), GUIErrorDevelopingScreen::new);
		event.register(DigitechModMenus.EXAMPLE_PULSE_EXPANSOR.get(), ExamplePulseExpansorScreen::new);
		event.register(DigitechModMenus.EXAMPLE_PULSE_LIMITATOR.get(), ExamplePulseLimitatorScreen::new);
		event.register(DigitechModMenus.REDSTONEDOORSMENU.get(), RedstonedoorsmenuScreen::new);
		event.register(DigitechModMenus.EXAMPLE_NOT_DOOR.get(), ExampleNotDoorScreen::new);
		event.register(DigitechModMenus.EXAMPLE_OR_DOOR.get(), ExampleORDoorScreen::new);
		event.register(DigitechModMenus.EXAMPLE_NOR_DOOR.get(), ExampleNORDoorScreen::new);
		event.register(DigitechModMenus.EXAMPLE_1_AND_DOOR.get(), Example1AndDoorScreen::new);
		event.register(DigitechModMenus.EXAMPLE_2_AND_DOOR.get(), Example2AndDoorScreen::new);
		event.register(DigitechModMenus.SETTINGS_GUI.get(), SettingsGuiScreen::new);
		event.register(DigitechModMenus.SET_PHONE.get(), SetPhoneScreen::new);
		event.register(DigitechModMenus.COMBAT_WIKI.get(), CombatWikiScreen::new);
		event.register(DigitechModMenus.HOME_GUI.get(), HomeGUIScreen::new);
		event.register(DigitechModMenus.ENDERCHEST.get(), EnderchestScreen::new);
		event.register(DigitechModMenus.MENU_PULSE.get(), MenuPulseScreen::new);
		event.register(DigitechModMenus.SET_WIFI_GUI.get(), SetWifiGUIScreen::new);
	}
}
